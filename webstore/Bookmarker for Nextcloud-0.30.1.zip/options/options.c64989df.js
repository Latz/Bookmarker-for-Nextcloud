
function $parcel$interopDefault(a) {
  return a && a.__esModule ? a.default : a;
}

      var $parcel$global = globalThis;
    
var $parcel$modules = {};
var $parcel$inits = {};

var parcelRequire = $parcel$global["parcelRequire4529"];

if (parcelRequire == null) {
  parcelRequire = function(id) {
    if (id in $parcel$modules) {
      return $parcel$modules[id].exports;
    }
    if (id in $parcel$inits) {
      var init = $parcel$inits[id];
      delete $parcel$inits[id];
      var module = {id: id, exports: {}};
      $parcel$modules[id] = module;
      init.call(module.exports, module, module.exports);
      return module.exports;
    }
    var err = new Error("Cannot find module '" + id + "'");
    err.code = 'MODULE_NOT_FOUND';
    throw err;
  };

  parcelRequire.register = function register(id, init) {
    $parcel$inits[id] = init;
  };

  $parcel$global["parcelRequire4529"] = parcelRequire;
}

var parcelRegister = parcelRequire.register;
// https://developer.chrome.com/docs/extensions/mv3/options/

var $9FxNy = parcelRequire("9FxNy");
var $cbba9abc09aaccd8$exports = {};
/*
Tagify v4.24.0 - tags input component
By: Yair Even-Or <vsync.design@gmail.com>
https://github.com/yairEO/tagify

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

This Software may not be rebranded and sold as a library under any other name
other than "Tagify" (by owner) or as part of another library.
*/ !function(t1, e) {
    $cbba9abc09aaccd8$exports = e();
}($cbba9abc09aaccd8$exports, function() {
    "use strict";
    var t1 = "&#8203;";
    function e(t1, e) {
        (null == e || e > t1.length) && (e = t1.length);
        for(var i = 0, n = new Array(e); i < e; i++)n[i] = t1[i];
        return n;
    }
    function i(t1) {
        return function(t1) {
            if (Array.isArray(t1)) return e(t1);
        }(t1) || function(t1) {
            if ("undefined" != typeof Symbol && null != t1[Symbol.iterator] || null != t1["@@iterator"]) return Array.from(t1);
        }(t1) || function(t1, i) {
            if (!t1) return;
            if ("string" == typeof t1) return e(t1, i);
            var n = Object.prototype.toString.call(t1).slice(8, -1);
            "Object" === n && t1.constructor && (n = t1.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(n);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return e(t1, i);
        }(t1) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }();
    }
    var n = {
        isEnabled: function() {
            var t1;
            return null === (t1 = window.TAGIFY_DEBUG) || void 0 === t1 || t1;
        },
        log: function() {
            for(var t1 = arguments.length, e = new Array(t1), n = 0; n < t1; n++)e[n] = arguments[n];
            var s;
            this.isEnabled() && (s = console).log.apply(s, [
                "[Tagify]:"
            ].concat(i(e)));
        },
        warn: function() {
            for(var t1 = arguments.length, e = new Array(t1), n = 0; n < t1; n++)e[n] = arguments[n];
            var s;
            this.isEnabled() && (s = console).warn.apply(s, [
                "[Tagify]:"
            ].concat(i(e)));
        }
    }, s = function(t1, e, i, n) {
        return t1 = "" + t1, e = "" + e, n && (t1 = t1.trim(), e = e.trim()), i ? t1 == e : t1.toLowerCase() == e.toLowerCase();
    }, a = function(t1, e) {
        return t1 && Array.isArray(t1) && t1.map(function(t1) {
            return o(t1, e);
        });
    };
    function o(t1, e) {
        var i, n = {};
        for(i in t1)e.indexOf(i) < 0 && (n[i] = t1[i]);
        return n;
    }
    function r(t1) {
        var e = document.createElement("div");
        return t1.replace(/\&#?[0-9a-z]+;/gi, function(t1) {
            return e.innerHTML = t1, e.innerText;
        });
    }
    function l(t1) {
        return (new DOMParser).parseFromString(t1.trim(), "text/html").body.firstElementChild;
    }
    function d(t1, e) {
        for(e = e || "previous"; t1 = t1[e + "Sibling"];)if (3 == t1.nodeType) return t1;
    }
    function c(t1) {
        return "string" == typeof t1 ? t1.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/`|'/g, "&#039;") : t1;
    }
    function u(t1) {
        var e = Object.prototype.toString.call(t1).split(" ")[1].slice(0, -1);
        return t1 === Object(t1) && "Array" != e && "Function" != e && "RegExp" != e && "HTMLUnknownElement" != e;
    }
    function g(t1, e, i) {
        var n, s;
        function a(t1, e) {
            for(var i in e)if (e.hasOwnProperty(i)) {
                if (u(e[i])) {
                    u(t1[i]) ? a(t1[i], e[i]) : t1[i] = Object.assign({}, e[i]);
                    continue;
                }
                if (Array.isArray(e[i])) {
                    t1[i] = Object.assign([], e[i]);
                    continue;
                }
                t1[i] = e[i];
            }
        }
        return n = t1, (null != (s = Object) && "undefined" != typeof Symbol && s[Symbol.hasInstance] ? s[Symbol.hasInstance](n) : n instanceof s) || (t1 = {}), a(t1, e), i && a(t1, i), t1;
    }
    function h() {
        var t1 = [], e = {}, i = !0, n = !1, s = void 0;
        try {
            for(var a, o = arguments[Symbol.iterator](); !(i = (a = o.next()).done); i = !0){
                var r = a.value, l = !0, d = !1, c = void 0;
                try {
                    for(var g, h = r[Symbol.iterator](); !(l = (g = h.next()).done); l = !0){
                        var p = g.value;
                        u(p) ? e[p.value] || (t1.push(p), e[p.value] = 1) : t1.includes(p) || t1.push(p);
                    }
                } catch (t1) {
                    d = !0, c = t1;
                } finally{
                    try {
                        l || null == h.return || h.return();
                    } finally{
                        if (d) throw c;
                    }
                }
            }
        } catch (t1) {
            n = !0, s = t1;
        } finally{
            try {
                i || null == o.return || o.return();
            } finally{
                if (n) throw s;
            }
        }
        return t1;
    }
    function p(t1) {
        return String.prototype.normalize ? "string" == typeof t1 ? t1.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : void 0 : t1;
    }
    var f = function() {
        return /(?=.*chrome)(?=.*android)/i.test(navigator.userAgent);
    };
    function m() {
        return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, function(t1) {
            return (t1 ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> t1 / 4).toString(16);
        });
    }
    function v(t1) {
        return t1 && t1.classList && t1.classList.contains(this.settings.classNames.tag);
    }
    function b(t1) {
        return t1 && t1.closest(this.settings.classNames.tagSelector);
    }
    function y(t1, e) {
        var i = window.getSelection();
        return e = e || i.getRangeAt(0), "string" == typeof t1 && (t1 = document.createTextNode(t1)), e && (e.deleteContents(), e.insertNode(t1)), t1;
    }
    function w(t1, e, i) {
        return t1 ? (e && (t1.__tagifyTagData = i ? e : g({}, t1.__tagifyTagData || {}, e)), t1.__tagifyTagData) : (n.warn("tag element doesn't exist", {
            tagElm: t1,
            data: e
        }), e);
    }
    function T(t1) {
        if (t1 && t1.parentNode) {
            var e = t1, i = window.getSelection(), n = i.getRangeAt(0);
            i.rangeCount && (n.setStartAfter(e), n.collapse(!0), i.removeAllRanges(), i.addRange(n));
        }
    }
    function O(t1, e) {
        t1.forEach(function(t1) {
            if (w(t1.previousSibling) || !t1.previousSibling) {
                var i = document.createTextNode("\u200B");
                t1.before(i), e && T(i);
            }
        });
    }
    var x = {
        delimiters: ",",
        pattern: null,
        tagTextProp: "value",
        maxTags: 1 / 0,
        callbacks: {},
        addTagOnBlur: !0,
        addTagOn: [
            "blur",
            "tab",
            "enter"
        ],
        onChangeAfterBlur: !0,
        duplicates: !1,
        whitelist: [],
        blacklist: [],
        enforceWhitelist: !1,
        userInput: !0,
        focusable: !0,
        keepInvalidTags: !1,
        createInvalidTags: !0,
        mixTagsAllowedAfter: /,|\.|\:|\s/,
        mixTagsInterpolator: [
            "[[",
            "]]"
        ],
        backspace: !0,
        skipInvalid: !1,
        pasteAsTags: !0,
        editTags: {
            clicks: 2,
            keepInvalid: !0
        },
        transformTag: function() {},
        trim: !0,
        a11y: {
            focusableTags: !1
        },
        mixMode: {
            insertAfterTag: "\xa0"
        },
        autoComplete: {
            enabled: !0,
            rightKey: !1,
            tabKey: !1
        },
        classNames: {
            namespace: "tagify",
            mixMode: "tagify--mix",
            selectMode: "tagify--select",
            input: "tagify__input",
            focus: "tagify--focus",
            tagNoAnimation: "tagify--noAnim",
            tagInvalid: "tagify--invalid",
            tagNotAllowed: "tagify--notAllowed",
            scopeLoading: "tagify--loading",
            hasMaxTags: "tagify--hasMaxTags",
            hasNoTags: "tagify--noTags",
            empty: "tagify--empty",
            inputInvalid: "tagify__input--invalid",
            dropdown: "tagify__dropdown",
            dropdownWrapper: "tagify__dropdown__wrapper",
            dropdownHeader: "tagify__dropdown__header",
            dropdownFooter: "tagify__dropdown__footer",
            dropdownItem: "tagify__dropdown__item",
            dropdownItemActive: "tagify__dropdown__item--active",
            dropdownItemHidden: "tagify__dropdown__item--hidden",
            dropdownInital: "tagify__dropdown--initial",
            tag: "tagify__tag",
            tagText: "tagify__tag-text",
            tagX: "tagify__tag__removeBtn",
            tagLoading: "tagify__tag--loading",
            tagEditing: "tagify__tag--editable",
            tagFlash: "tagify__tag--flash",
            tagHide: "tagify__tag--hide"
        },
        dropdown: {
            classname: "",
            enabled: 2,
            maxItems: 10,
            searchKeys: [
                "value",
                "searchBy"
            ],
            fuzzySearch: !0,
            caseSensitive: !1,
            accentedSearch: !0,
            includeSelectedTags: !1,
            escapeHTML: !0,
            highlightFirst: !0,
            closeOnSelect: !0,
            clearOnSelect: !0,
            position: "all",
            appendTarget: null
        },
        hooks: {
            beforeRemoveTag: function() {
                return Promise.resolve();
            },
            beforePaste: function() {
                return Promise.resolve();
            },
            suggestionClick: function() {
                return Promise.resolve();
            },
            beforeKeyDown: function() {
                return Promise.resolve();
            }
        }
    };
    function D(t1, e, i) {
        return e in t1 ? Object.defineProperty(t1, e, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t1[e] = i, t1;
    }
    function S(t1) {
        for(var e = 1; e < arguments.length; e++){
            var i = null != arguments[e] ? arguments[e] : {}, n = Object.keys(i);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(i).filter(function(t1) {
                return Object.getOwnPropertyDescriptor(i, t1).enumerable;
            }))), n.forEach(function(e) {
                D(t1, e, i[e]);
            });
        }
        return t1;
    }
    function I(t1, e) {
        return e = null != e ? e : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(t1, Object.getOwnPropertyDescriptors(e)) : (function(t1, e) {
            var i = Object.keys(t1);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t1);
                e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t1, e).enumerable;
                })), i.push.apply(i, n);
            }
            return i;
        })(Object(e)).forEach(function(i) {
            Object.defineProperty(t1, i, Object.getOwnPropertyDescriptor(e, i));
        }), t1;
    }
    var M = {
        events: {
            binding: function() {
                var t1 = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], e = this.dropdown.events.callbacks, i = this.listeners.dropdown = this.listeners.dropdown || {
                    position: this.dropdown.position.bind(this, null),
                    onKeyDown: e.onKeyDown.bind(this),
                    onMouseOver: e.onMouseOver.bind(this),
                    onMouseLeave: e.onMouseLeave.bind(this),
                    onClick: e.onClick.bind(this),
                    onScroll: e.onScroll.bind(this)
                }, n = t1 ? "addEventListener" : "removeEventListener";
                "manual" != this.settings.dropdown.position && (document[n]("scroll", i.position, !0), window[n]("resize", i.position), window[n]("keydown", i.onKeyDown)), this.DOM.dropdown[n]("mouseover", i.onMouseOver), this.DOM.dropdown[n]("mouseleave", i.onMouseLeave), this.DOM.dropdown[n]("mousedown", i.onClick), this.DOM.dropdown.content[n]("scroll", i.onScroll);
            },
            callbacks: {
                onKeyDown: function(t1) {
                    var e = this;
                    if (this.state.hasFocus && !this.state.composing) {
                        var i = this.settings, s = this.DOM.dropdown.querySelector(i.classNames.dropdownItemActiveSelector), a = this.dropdown.getSuggestionDataByNode(s), o = "mix" == i.mode, r = "select" == i.mode;
                        i.hooks.beforeKeyDown(t1, {
                            tagify: this
                        }).then(function(l) {
                            switch(t1.key){
                                case "ArrowDown":
                                case "ArrowUp":
                                case "Down":
                                case "Up":
                                    t1.preventDefault();
                                    var d = e.dropdown.getAllSuggestionsRefs(), c = "ArrowUp" == t1.key || "Up" == t1.key;
                                    s && (s = e.dropdown.getNextOrPrevOption(s, !c)), s && s.matches(i.classNames.dropdownItemSelector) || (s = d[c ? d.length - 1 : 0]), e.dropdown.highlightOption(s, !0);
                                    break;
                                case "Escape":
                                case "Esc":
                                    e.dropdown.hide();
                                    break;
                                case "ArrowRight":
                                    if (e.state.actions.ArrowLeft) return;
                                case "Tab":
                                    var u = !i.autoComplete.rightKey || !i.autoComplete.tabKey;
                                    if (!o && !r && s && u && !e.state.editing) {
                                        t1.preventDefault();
                                        var g = e.dropdown.getMappedValue(a);
                                        return e.input.autocomplete.set.call(e, g), !1;
                                    }
                                    return !0;
                                case "Enter":
                                    t1.preventDefault(), i.hooks.suggestionClick(t1, {
                                        tagify: e,
                                        tagData: a,
                                        suggestionElm: s
                                    }).then(function() {
                                        if (s) return e.dropdown.selectOption(s), s = e.dropdown.getNextOrPrevOption(s, !c), void e.dropdown.highlightOption(s);
                                        e.dropdown.hide(), o || e.addTags(e.state.inputText.trim(), !0);
                                    }).catch(function(t1) {
                                        return n.warn(t1);
                                    });
                                    break;
                                case "Backspace":
                                    if (o || e.state.editing.scope) return;
                                    var h = e.input.raw.call(e);
                                    "" != h && 8203 != h.charCodeAt(0) || (!0 === i.backspace ? e.removeTags() : "edit" == i.backspace && setTimeout(e.editTag.bind(e), 0));
                            }
                        });
                    }
                },
                onMouseOver: function(t1) {
                    var e = t1.target.closest(this.settings.classNames.dropdownItemSelector);
                    this.dropdown.highlightOption(e);
                },
                onMouseLeave: function(t1) {
                    this.dropdown.highlightOption();
                },
                onClick: function(t1) {
                    var e = this;
                    if (0 == t1.button && t1.target != this.DOM.dropdown && t1.target != this.DOM.dropdown.content) {
                        var i = t1.target.closest(this.settings.classNames.dropdownItemSelector), s = this.dropdown.getSuggestionDataByNode(i);
                        this.state.actions.selectOption = !0, setTimeout(function() {
                            return e.state.actions.selectOption = !1;
                        }, 50), this.settings.hooks.suggestionClick(t1, {
                            tagify: this,
                            tagData: s,
                            suggestionElm: i
                        }).then(function() {
                            i ? e.dropdown.selectOption(i, t1) : e.dropdown.hide();
                        }).catch(function(t1) {
                            return n.warn(t1);
                        });
                    }
                },
                onScroll: function(t1) {
                    var e = t1.target, i = e.scrollTop / (e.scrollHeight - e.parentNode.clientHeight) * 100;
                    this.trigger("dropdown:scroll", {
                        percentage: Math.round(i)
                    });
                }
            }
        },
        refilter: function(t1) {
            t1 = t1 || this.state.dropdown.query || "", this.suggestedListItems = this.dropdown.filterListItems(t1), this.dropdown.fill(), this.suggestedListItems.length || this.dropdown.hide(), this.trigger("dropdown:updated", this.DOM.dropdown);
        },
        getSuggestionDataByNode: function(t1) {
            var e = t1 && t1.getAttribute("value");
            return this.suggestedListItems.find(function(t1) {
                return t1.value == e;
            }) || null;
        },
        getNextOrPrevOption: function(t1) {
            var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], i = this.dropdown.getAllSuggestionsRefs(), n = i.findIndex(function(e) {
                return e === t1;
            });
            return e ? i[n + 1] : i[n - 1];
        },
        highlightOption: function(t1, e) {
            var i, n = this.settings.classNames.dropdownItemActive;
            if (this.state.ddItemElm && (this.state.ddItemElm.classList.remove(n), this.state.ddItemElm.removeAttribute("aria-selected")), !t1) return this.state.ddItemData = null, this.state.ddItemElm = null, void this.input.autocomplete.suggest.call(this);
            i = this.dropdown.getSuggestionDataByNode(t1), this.state.ddItemData = i, this.state.ddItemElm = t1, t1.classList.add(n), t1.setAttribute("aria-selected", !0), e && (t1.parentNode.scrollTop = t1.clientHeight + t1.offsetTop - t1.parentNode.clientHeight), this.settings.autoComplete && (this.input.autocomplete.suggest.call(this, i), this.dropdown.position());
        },
        selectOption: function(t1, e) {
            var i = this, n = this.settings, s = n.dropdown, a = s.clearOnSelect, o = s.closeOnSelect;
            if (!t1) return this.addTags(this.state.inputText, !0), void (o && this.dropdown.hide());
            e = e || {};
            var r = t1.getAttribute("value"), l = "noMatch" == r, d = "mix" == n.mode, c = this.suggestedListItems.find(function(t1) {
                var e;
                return (null !== (e = t1.value) && void 0 !== e ? e : t1) == r;
            });
            if (this.trigger("dropdown:select", {
                data: c,
                elm: t1,
                event: e
            }), r && (c || l)) {
                if (this.state.editing) {
                    var u = this.normalizeTags([
                        c
                    ])[0];
                    c = n.transformTag.call(this, u) || u, this.onEditTagDone(null, g({
                        __isValid: !0
                    }, c));
                } else this[d ? "addMixTags" : "addTags"]([
                    c || this.input.raw.call(this)
                ], a);
                (d || this.DOM.input.parentNode) && (setTimeout(function() {
                    i.DOM.input.focus(), i.toggleFocusClass(!0);
                }), o && setTimeout(this.dropdown.hide.bind(this)), t1.addEventListener("transitionend", function() {
                    i.dropdown.fillHeaderFooter(), setTimeout(function() {
                        return t1.remove();
                    }, 100);
                }, {
                    once: !0
                }), t1.classList.add(this.settings.classNames.dropdownItemHidden));
            } else o && setTimeout(this.dropdown.hide.bind(this));
        },
        selectAll: function(t1) {
            this.suggestedListItems.length = 0, this.dropdown.hide(), this.dropdown.filterListItems("");
            var e = this.dropdown.filterListItems("");
            return t1 || (e = this.state.dropdown.suggestions), this.addTags(e, !0), this;
        },
        filterListItems: function(t1, e) {
            var i, n, s, a, o, r, l = function() {
                var t1, l, d = void 0, c = void 0;
                t1 = m[y], n = (null != (l = Object) && "undefined" != typeof Symbol && l[Symbol.hasInstance] ? l[Symbol.hasInstance](t1) : t1 instanceof l) ? m[y] : {
                    value: m[y]
                };
                var v, w = !Object.keys(n).some(function(t1) {
                    return b.includes(t1);
                }) ? [
                    "value"
                ] : b;
                g.fuzzySearch && !e.exact ? (a = w.reduce(function(t1, e) {
                    return t1 + " " + (n[e] || "");
                }, "").toLowerCase().trim(), g.accentedSearch && (a = p(a), r = p(r)), d = 0 == a.indexOf(r), c = a === r, v = a, s = r.toLowerCase().split(" ").every(function(t1) {
                    return v.includes(t1.toLowerCase());
                })) : (d = !0, s = w.some(function(t1) {
                    var i = "" + (n[t1] || "");
                    return g.accentedSearch && (i = p(i), r = p(r)), g.caseSensitive || (i = i.toLowerCase()), c = i === r, e.exact ? i === r : 0 == i.indexOf(r);
                })), o = !g.includeSelectedTags && i.isTagDuplicate(u(n) ? n.value : n), s && !o && (c && d ? f.push(n) : "startsWith" == g.sortby && d ? h.unshift(n) : h.push(n));
            }, d = this, c = this.settings, g = c.dropdown, h = (e = e || {}, []), f = [], m = c.whitelist, v = g.maxItems >= 0 ? g.maxItems : 1 / 0, b = g.searchKeys, y = 0;
            if (!(t1 = "select" == c.mode && this.value.length && this.value[0][c.tagTextProp] == t1 ? "" : t1) || !b.length) return h = g.includeSelectedTags ? m : m.filter(function(t1) {
                return !d.isTagDuplicate(u(t1) ? t1.value : t1);
            }), this.state.dropdown.suggestions = h, h.slice(0, v);
            for(r = g.caseSensitive ? "" + t1 : ("" + t1).toLowerCase(); y < m.length; y++)i = this, l();
            return this.state.dropdown.suggestions = f.concat(h), "function" == typeof g.sortby ? g.sortby(f.concat(h), r) : f.concat(h).slice(0, v);
        },
        getMappedValue: function(t1) {
            var e = this.settings.dropdown.mapValueTo;
            return e ? "function" == typeof e ? e(t1) : t1[e] || t1.value : t1.value;
        },
        createListHTML: function(t1) {
            var e = this;
            return g([], t1).map(function(t1, i) {
                "string" != typeof t1 && "number" != typeof t1 || (t1 = {
                    value: t1
                });
                var n = e.dropdown.getMappedValue(t1);
                return n = "string" == typeof n && e.settings.dropdown.escapeHTML ? c(n) : n, e.settings.templates.dropdownItem.apply(e, [
                    I(S({}, t1), {
                        mappedValue: n
                    }),
                    e
                ]);
            }).join("");
        }
    };
    function E(t1, e) {
        (null == e || e > t1.length) && (e = t1.length);
        for(var i = 0, n = new Array(e); i < e; i++)n[i] = t1[i];
        return n;
    }
    function N(t1, e, i) {
        return e in t1 ? Object.defineProperty(t1, e, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t1[e] = i, t1;
    }
    function _(t1) {
        return function(t1) {
            if (Array.isArray(t1)) return E(t1);
        }(t1) || function(t1) {
            if ("undefined" != typeof Symbol && null != t1[Symbol.iterator] || null != t1["@@iterator"]) return Array.from(t1);
        }(t1) || function(t1, e) {
            if (!t1) return;
            if ("string" == typeof t1) return E(t1, e);
            var i = Object.prototype.toString.call(t1).slice(8, -1);
            "Object" === i && t1.constructor && (i = t1.constructor.name);
            if ("Map" === i || "Set" === i) return Array.from(i);
            if ("Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)) return E(t1, e);
        }(t1) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }();
    }
    function A() {
        for(var t1 in this.dropdown = {}, this._dropdown)this.dropdown[t1] = "function" == typeof this._dropdown[t1] ? this._dropdown[t1].bind(this) : this._dropdown[t1];
        this.dropdown.refs();
    }
    var C, k, L, P = (C = function(t1) {
        for(var e = 1; e < arguments.length; e++){
            var i = null != arguments[e] ? arguments[e] : {}, n = Object.keys(i);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(i).filter(function(t1) {
                return Object.getOwnPropertyDescriptor(i, t1).enumerable;
            }))), n.forEach(function(e) {
                N(t1, e, i[e]);
            });
        }
        return t1;
    }({}, M), k = (k = {
        refs: function() {
            this.DOM.dropdown = this.parseTemplate("dropdown", [
                this.settings
            ]), this.DOM.dropdown.content = this.DOM.dropdown.querySelector("[data-selector='tagify-suggestions-wrapper']");
        },
        getHeaderRef: function() {
            return this.DOM.dropdown.querySelector("[data-selector='tagify-suggestions-header']");
        },
        getFooterRef: function() {
            return this.DOM.dropdown.querySelector("[data-selector='tagify-suggestions-footer']");
        },
        getAllSuggestionsRefs: function() {
            return _(this.DOM.dropdown.content.querySelectorAll(this.settings.classNames.dropdownItemSelector));
        },
        show: function(t1) {
            var e, i, n, a = this, o = this.settings, r = "mix" == o.mode && !o.enforceWhitelist, l = !o.whitelist || !o.whitelist.length, d = "manual" == o.dropdown.position;
            if (t1 = void 0 === t1 ? this.state.inputText : t1, !(l && !r && !o.templates.dropdownItemNoMatch || !1 === o.dropdown.enable || this.state.isLoading || this.settings.readonly)) {
                if (clearTimeout(this.dropdownHide__bindEventsTimeout), this.suggestedListItems = this.dropdown.filterListItems(t1), t1 && !this.suggestedListItems.length && (this.trigger("dropdown:noMatch", t1), o.templates.dropdownItemNoMatch && (n = o.templates.dropdownItemNoMatch.call(this, {
                    value: t1
                }))), !n) {
                    if (this.suggestedListItems.length) t1 && r && !this.state.editing.scope && !s(this.suggestedListItems[0].value, t1) && this.suggestedListItems.unshift({
                        value: t1
                    });
                    else {
                        if (!t1 || !r || this.state.editing.scope) return this.input.autocomplete.suggest.call(this), void this.dropdown.hide();
                        this.suggestedListItems = [
                            {
                                value: t1
                            }
                        ];
                    }
                    i = "" + (u(e = this.suggestedListItems[0]) ? e.value : e), o.autoComplete && i && 0 == i.indexOf(t1) && this.input.autocomplete.suggest.call(this, e);
                }
                this.dropdown.fill(n), o.dropdown.highlightFirst && this.dropdown.highlightOption(this.DOM.dropdown.content.querySelector(o.classNames.dropdownItemSelector)), this.state.dropdown.visible || setTimeout(this.dropdown.events.binding.bind(this)), this.state.dropdown.visible = t1 || !0, this.state.dropdown.query = t1, this.setStateSelection(), d || setTimeout(function() {
                    a.dropdown.position(), a.dropdown.render();
                }), setTimeout(function() {
                    a.trigger("dropdown:show", a.DOM.dropdown);
                });
            }
        },
        hide: function(t1) {
            var e = this, i = this.DOM, n = i.scope, s = i.dropdown, a = "manual" == this.settings.dropdown.position && !t1;
            if (s && document.body.contains(s) && !a) return window.removeEventListener("resize", this.dropdown.position), this.dropdown.events.binding.call(this, !1), n.setAttribute("aria-expanded", !1), s.parentNode.removeChild(s), setTimeout(function() {
                e.state.dropdown.visible = !1;
            }, 100), this.state.dropdown.query = this.state.ddItemData = this.state.ddItemElm = this.state.selection = null, this.state.tag && this.state.tag.value.length && (this.state.flaggedTags[this.state.tag.baseOffset] = this.state.tag), this.trigger("dropdown:hide", s), this;
        },
        toggle: function(t1) {
            this.dropdown[this.state.dropdown.visible && !t1 ? "hide" : "show"]();
        },
        getAppendTarget: function() {
            var t1 = this.settings.dropdown;
            return "function" == typeof t1.appendTarget ? t1.appendTarget() : t1.appendTarget;
        },
        render: function() {
            var t1, e, i, n = this, s = (t1 = this.DOM.dropdown, (i = t1.cloneNode(!0)).style.cssText = "position:fixed; top:-9999px; opacity:0", document.body.appendChild(i), e = i.clientHeight, i.parentNode.removeChild(i), e), a = this.settings, o = "number" == typeof a.dropdown.enabled && a.dropdown.enabled >= 0, r = this.dropdown.getAppendTarget();
            return o ? (this.DOM.scope.setAttribute("aria-expanded", !0), document.body.contains(this.DOM.dropdown) || (this.DOM.dropdown.classList.add(a.classNames.dropdownInital), this.dropdown.position(s), r.appendChild(this.DOM.dropdown), setTimeout(function() {
                return n.DOM.dropdown.classList.remove(a.classNames.dropdownInital);
            })), this) : this;
        },
        fill: function(t1) {
            t1 = "string" == typeof t1 ? t1 : this.dropdown.createListHTML(t1 || this.suggestedListItems);
            var e, i = this.settings.templates.dropdownContent.call(this, t1);
            this.DOM.dropdown.content.innerHTML = (e = i) ? e.replace(/\>[\r\n ]+\</g, "><").split(/>\s+</).join("><").trim() : "";
        },
        fillHeaderFooter: function() {
            var t1 = this.dropdown.filterListItems(this.state.dropdown.query), e = this.parseTemplate("dropdownHeader", [
                t1
            ]), i = this.parseTemplate("dropdownFooter", [
                t1
            ]), n = this.dropdown.getHeaderRef(), s = this.dropdown.getFooterRef();
            e && (null == n || n.parentNode.replaceChild(e, n)), i && (null == s || s.parentNode.replaceChild(i, s));
        },
        position: function(t1) {
            var e = this.settings.dropdown, i = this.dropdown.getAppendTarget();
            if ("manual" != e.position && i) {
                var n, s, a, o, r, l, d, c, u, g = this.DOM.dropdown, h = e.RTL, p = i === document.body, f = i === this.DOM.scope, m = p ? window.pageYOffset : i.scrollTop, v = document.fullscreenElement || document.webkitFullscreenElement || document.documentElement, b = v.clientHeight, y = Math.max(v.clientWidth || 0, window.innerWidth || 0) > 480 ? e.position : "all", w = this.DOM["input" == y ? "input" : "scope"];
                if (t1 = t1 || g.clientHeight, this.state.dropdown.visible) {
                    if ("text" == y ? (a = (n = function() {
                        var t1 = document.getSelection();
                        if (t1.rangeCount) {
                            var e, i, n = t1.getRangeAt(0), s = n.startContainer, a = n.startOffset;
                            if (a > 0) return (i = document.createRange()).setStart(s, a - 1), i.setEnd(s, a), {
                                left: (e = i.getBoundingClientRect()).right,
                                top: e.top,
                                bottom: e.bottom
                            };
                            if (s.getBoundingClientRect) return s.getBoundingClientRect();
                        }
                        return {
                            left: -9999,
                            top: -9999
                        };
                    }()).bottom, s = n.top, o = n.left, r = "auto") : (l = function(t1) {
                        var e = 0, i = 0;
                        for(t1 = t1.parentNode; t1 && t1 != v;)e += t1.offsetTop || 0, i += t1.offsetLeft || 0, t1 = t1.parentNode;
                        return {
                            top: e,
                            left: i
                        };
                    }(i), n = w.getBoundingClientRect(), s = f ? -1 : n.top - l.top, a = (f ? n.height : n.bottom - l.top) - 1, o = f ? -1 : n.left - l.left, r = n.width + "px"), !p) {
                        var T = function() {
                            for(var t1 = 0, i = e.appendTarget.parentNode; i;)t1 += i.scrollTop || 0, i = i.parentNode;
                            return t1;
                        }();
                        s += T, a += T;
                    }
                    var O;
                    s = Math.floor(s), a = Math.ceil(a), c = ((d = null !== (O = e.placeAbove) && void 0 !== O ? O : b - n.bottom < t1) ? s : a) + m, u = "left: ".concat(o + (h && n.width || 0) + window.pageXOffset, "px;"), g.style.cssText = "".concat(u, "; top: ").concat(c, "px; min-width: ").concat(r, "; max-width: ").concat(r), g.setAttribute("placement", d ? "top" : "bottom"), g.setAttribute("position", y);
                }
            }
        }
    }, k), Object.getOwnPropertyDescriptors ? Object.defineProperties(C, Object.getOwnPropertyDescriptors(k)) : (function(t1, e) {
        var i = Object.keys(t1);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(t1);
            e && (n = n.filter(function(e) {
                return Object.getOwnPropertyDescriptor(t1, e).enumerable;
            })), i.push.apply(i, n);
        }
        return i;
    })(Object(k)).forEach(function(t1) {
        Object.defineProperty(C, t1, Object.getOwnPropertyDescriptor(k, t1));
    }), C), j = "@yaireo/tagify/", V = {
        empty: "empty",
        exceed: "number of tags exceeded",
        pattern: "pattern mismatch",
        duplicate: "already exists",
        notAllowed: "not allowed"
    }, R = {
        wrapper: function(e, i) {
            return '<tags class="'.concat(i.classNames.namespace, " ").concat(i.mode ? "".concat(i.classNames[i.mode + "Mode"]) : "", " ").concat(e.className, '"\n                    ').concat(i.readonly ? "readonly" : "", "\n                    ").concat(i.disabled ? "disabled" : "", "\n                    ").concat(i.required ? "required" : "", "\n                    ").concat("select" === i.mode ? "spellcheck='false'" : "", '\n                    tabIndex="-1">\n            <span ').concat(!i.readonly && i.userInput ? "contenteditable" : "", ' tabIndex="0" data-placeholder="').concat(i.placeholder || t1, '" aria-placeholder="').concat(i.placeholder || "", '"\n                class="').concat(i.classNames.input, '"\n                role="textbox"\n                aria-autocomplete="both"\n                aria-multiline="').concat("mix" == i.mode, '"></span>\n                ').concat(t1, "\n        </tags>");
        },
        tag: function(t1, e) {
            var i = e.settings;
            return '<tag title="'.concat(t1.title || t1.value, "\"\n                    contenteditable='false'\n                    spellcheck='false'\n                    tabIndex=\"").concat(i.a11y.focusableTags ? 0 : -1, '"\n                    class="').concat(i.classNames.tag, " ").concat(t1.class || "", '"\n                    ').concat(this.getAttributes(t1), ">\n            <x title='' tabIndex=\"").concat(i.a11y.focusableTags ? 0 : -1, '" class="').concat(i.classNames.tagX, "\" role='button' aria-label='remove tag'></x>\n            <div>\n                <span ").concat("select" === i.mode && i.userInput ? "contenteditable='true'" : "", ' class="').concat(i.classNames.tagText, '">').concat(t1[i.tagTextProp] || t1.value, "</span>\n            </div>\n        </tag>");
        },
        dropdown: function(t1) {
            var e = t1.dropdown, i = "manual" == e.position;
            return '<div class="'.concat(i ? "" : t1.classNames.dropdown, " ").concat(e.classname, '" role="listbox" aria-labelledby="dropdown" dir="').concat(e.RTL ? "rtl" : "", "\">\n                    <div data-selector='tagify-suggestions-wrapper' class=\"").concat(t1.classNames.dropdownWrapper, '"></div>\n                </div>');
        },
        dropdownContent: function(t1) {
            var e = this.settings.templates, i = this.state.dropdown.suggestions;
            return "\n            ".concat(e.dropdownHeader.call(this, i), "\n            ").concat(t1, "\n            ").concat(e.dropdownFooter.call(this, i), "\n        ");
        },
        dropdownItem: function(t1) {
            return "<div ".concat(this.getAttributes(t1), "\n                    class='").concat(this.settings.classNames.dropdownItem, " ").concat(t1.class || "", '\'\n                    tabindex="0"\n                    role="option">').concat(t1.mappedValue || t1.value, "</div>");
        },
        dropdownHeader: function(t1) {
            return "<header data-selector='tagify-suggestions-header' class=\"".concat(this.settings.classNames.dropdownHeader, '"></header>');
        },
        dropdownFooter: function(t1) {
            var e = t1.length - this.settings.dropdown.maxItems;
            return e > 0 ? "<footer data-selector='tagify-suggestions-footer' class=\"".concat(this.settings.classNames.dropdownFooter, '">\n                ').concat(e, " more items. Refine your search.\n            </footer>") : "";
        },
        dropdownItemNoMatch: null
    };
    function F(t1, e) {
        (null == e || e > t1.length) && (e = t1.length);
        for(var i = 0, n = new Array(e); i < e; i++)n[i] = t1[i];
        return n;
    }
    function H(t1, e) {
        return null != e && "undefined" != typeof Symbol && e[Symbol.hasInstance] ? !!e[Symbol.hasInstance](t1) : t1 instanceof e;
    }
    function B(t1, e) {
        return function(t1) {
            if (Array.isArray(t1)) return t1;
        }(t1) || function(t1, e) {
            var i = null == t1 ? null : "undefined" != typeof Symbol && t1[Symbol.iterator] || t1["@@iterator"];
            if (null != i) {
                var n, s, a = [], o = !0, r = !1;
                try {
                    for(i = i.call(t1); !(o = (n = i.next()).done) && (a.push(n.value), !e || a.length !== e); o = !0);
                } catch (t1) {
                    r = !0, s = t1;
                } finally{
                    try {
                        o || null == i.return || i.return();
                    } finally{
                        if (r) throw s;
                    }
                }
                return a;
            }
        }(t1, e) || function(t1, e) {
            if (!t1) return;
            if ("string" == typeof t1) return F(t1, e);
            var i = Object.prototype.toString.call(t1).slice(8, -1);
            "Object" === i && t1.constructor && (i = t1.constructor.name);
            if ("Map" === i || "Set" === i) return Array.from(i);
            if ("Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)) return F(t1, e);
        }(t1, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }();
    }
    function W(t1, e) {
        (null == e || e > t1.length) && (e = t1.length);
        for(var i = 0, n = new Array(e); i < e; i++)n[i] = t1[i];
        return n;
    }
    function U(t1, e, i) {
        return e in t1 ? Object.defineProperty(t1, e, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t1[e] = i, t1;
    }
    function q(t1, e) {
        return null != e && "undefined" != typeof Symbol && e[Symbol.hasInstance] ? !!e[Symbol.hasInstance](t1) : t1 instanceof e;
    }
    function K(t1, e) {
        return e = null != e ? e : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(t1, Object.getOwnPropertyDescriptors(e)) : (function(t1, e) {
            var i = Object.keys(t1);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t1);
                e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t1, e).enumerable;
                })), i.push.apply(i, n);
            }
            return i;
        })(Object(e)).forEach(function(i) {
            Object.defineProperty(t1, i, Object.getOwnPropertyDescriptor(e, i));
        }), t1;
    }
    function z(t1) {
        return function(t1) {
            if (Array.isArray(t1)) return W(t1);
        }(t1) || function(t1) {
            if ("undefined" != typeof Symbol && null != t1[Symbol.iterator] || null != t1["@@iterator"]) return Array.from(t1);
        }(t1) || function(t1, e) {
            if (!t1) return;
            if ("string" == typeof t1) return W(t1, e);
            var i = Object.prototype.toString.call(t1).slice(8, -1);
            "Object" === i && t1.constructor && (i = t1.constructor.name);
            if ("Map" === i || "Set" === i) return Array.from(i);
            if ("Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)) return W(t1, e);
        }(t1) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }();
    }
    var X = {
        customBinding: function() {
            var t1 = this;
            this.customEventsList.forEach(function(e) {
                t1.on(e, t1.settings.callbacks[e]);
            });
        },
        binding: function() {
            var t1, e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], i = this.settings, n = this.events.callbacks, s = e ? "addEventListener" : "removeEventListener";
            if (!this.state.mainEvents || !e) {
                for(var a in this.state.mainEvents = e, e && !this.listeners.main && (this.events.bindGlobal.call(this), this.settings.isJQueryPlugin && jQuery(this.DOM.originalInput).on("tagify.removeAllTags", this.removeAllTags.bind(this))), t1 = this.listeners.main = this.listeners.main || {
                    keydown: [
                        "input",
                        n.onKeydown.bind(this)
                    ],
                    click: [
                        "scope",
                        n.onClickScope.bind(this)
                    ],
                    dblclick: "select" != i.mode && [
                        "scope",
                        n.onDoubleClickScope.bind(this)
                    ],
                    paste: [
                        "input",
                        n.onPaste.bind(this)
                    ],
                    drop: [
                        "input",
                        n.onDrop.bind(this)
                    ],
                    compositionstart: [
                        "input",
                        n.onCompositionStart.bind(this)
                    ],
                    compositionend: [
                        "input",
                        n.onCompositionEnd.bind(this)
                    ]
                })t1[a] && this.DOM[t1[a][0]][s](a, t1[a][1]);
                clearInterval(this.listeners.main.originalInputValueObserverInterval), this.listeners.main.originalInputValueObserverInterval = setInterval(n.observeOriginalInputValue.bind(this), 500);
                var o = this.listeners.main.inputMutationObserver || new MutationObserver(n.onInputDOMChange.bind(this));
                o.disconnect(), "mix" == i.mode && o.observe(this.DOM.input, {
                    childList: !0
                });
            }
        },
        bindGlobal: function(t1) {
            var e, i = this.events.callbacks, n = t1 ? "removeEventListener" : "addEventListener";
            if (this.listeners && (t1 || !this.listeners.global)) {
                this.listeners.global = this.listeners.global || [
                    {
                        type: this.isIE ? "keydown" : "input",
                        target: this.DOM.input,
                        cb: i[this.isIE ? "onInputIE" : "onInput"].bind(this)
                    },
                    {
                        type: "keydown",
                        target: window,
                        cb: i.onWindowKeyDown.bind(this)
                    },
                    {
                        type: "focusin",
                        target: this.DOM.scope,
                        cb: i.onFocusBlur.bind(this)
                    },
                    {
                        type: "focusout",
                        target: this.DOM.scope,
                        cb: i.onFocusBlur.bind(this)
                    },
                    {
                        type: "click",
                        target: document,
                        cb: i.onClickAnywhere.bind(this),
                        useCapture: !0
                    }
                ];
                var s = !0, a = !1, o = void 0;
                try {
                    for(var r, l = this.listeners.global[Symbol.iterator](); !(s = (r = l.next()).done); s = !0)(e = r.value).target[n](e.type, e.cb, !!e.useCapture);
                } catch (t1) {
                    a = !0, o = t1;
                } finally{
                    try {
                        s || null == l.return || l.return();
                    } finally{
                        if (a) throw o;
                    }
                }
            }
        },
        unbindGlobal: function() {
            this.events.bindGlobal.call(this, !0);
        },
        callbacks: {
            onFocusBlur: function(t1) {
                var e, i, n, s = b.call(this, t1.target), a = v.call(this, t1.target), o = "focusin" == t1.type, r = "focusout" == t1.type, l = null === (e = t1.target) || void 0 === e ? void 0 : e.closest(this.settings.classNames.tagTextSelector);
                if (s && o && !a) return this.toggleFocusClass(this.state.hasFocus = +new Date), l ? this.events.callbacks.onEditTagFocus.call(this, s) : void 0;
                var d = this.settings, c = t1.target ? this.trim(this.DOM.input.textContent) : "", u = null === (n = this.value) || void 0 === n || null === (i = n[0]) || void 0 === i ? void 0 : i[d.tagTextProp], g = d.dropdown.enabled >= 0, h = {
                    relatedTarget: t1.relatedTarget
                }, p = this.state.actions.selectOption && (g || !d.dropdown.closeOnSelect), f = this.state.actions.addNew && g;
                if (r) {
                    if (t1.relatedTarget === this.DOM.scope) return this.dropdown.hide(), void this.DOM.input.focus();
                    this.postUpdate();
                }
                if (!p && !f) {
                    if (this.state.hasFocus = !!o && +new Date, this.toggleFocusClass(this.state.hasFocus), "mix" != d.mode) {
                        if (o) {
                            if (!d.focusable) return;
                            return this.toggleFocusClass(!0), this.trigger("focus", h), void (0 !== d.dropdown.enabled || this.state.dropdown.visible || this.dropdown.show(this.value.length ? "" : void 0));
                        }
                        if (r && !a) {
                            if (this.trigger("blur", h), this.loading(!1), "select" == d.mode) {
                                if (this.value.length) {
                                    var m = this.getTagElms()[0];
                                    c = this.trim(m.textContent);
                                }
                                u === c && (c = "");
                            }
                            c && !this.state.actions.selectOption && d.addTagOnBlur && d.addTagOn.includes("blur") && this.addTags(c, !0);
                        }
                        this.DOM.input.removeAttribute("style"), this.dropdown.hide();
                    } else o ? this.trigger("focus", h) : r && (this.trigger("blur", h), this.loading(!1), this.dropdown.hide(), this.state.dropdown.visible = void 0, this.setStateSelection());
                }
            },
            onCompositionStart: function(t1) {
                this.state.composing = !0;
            },
            onCompositionEnd: function(t1) {
                this.state.composing = !1;
            },
            onWindowKeyDown: function(t1) {
                var e, i = document.activeElement, n = v.call(this, i) && this.DOM.scope.contains(document.activeElement), s = n && i.hasAttribute("readonly");
                if (n && !s) switch(e = i.nextElementSibling, t1.key){
                    case "Backspace":
                        this.settings.readonly || (this.removeTags(i), (e || this.DOM.input).focus());
                        break;
                    case "Enter":
                        setTimeout(this.editTag.bind(this), 0, i);
                }
            },
            onKeydown: function(t1) {
                var e = this, i = this.settings;
                if (!this.state.composing && i.userInput) {
                    "select" == i.mode && i.enforceWhitelist && this.value.length && "Tab" != t1.key && t1.preventDefault();
                    var n = this.trim(t1.target.textContent);
                    this.trigger("keydown", {
                        event: t1
                    }), i.hooks.beforeKeyDown(t1, {
                        tagify: this
                    }).then(function(s) {
                        if ("mix" == i.mode) {
                            switch(t1.key){
                                case "Left":
                                case "ArrowLeft":
                                    e.state.actions.ArrowLeft = !0;
                                    break;
                                case "Delete":
                                case "Backspace":
                                    if (e.state.editing) return;
                                    var a = document.getSelection(), o = "Delete" == t1.key && a.anchorOffset == (a.anchorNode.length || 0), l = a.anchorNode.previousSibling, c = 1 == a.anchorNode.nodeType || !a.anchorOffset && l && 1 == l.nodeType && a.anchorNode.previousSibling;
                                    r(e.DOM.input.innerHTML);
                                    var u, g, h, p = e.getTagElms(), m = 1 === a.anchorNode.length && a.anchorNode.nodeValue == String.fromCharCode(8203);
                                    if ("edit" == i.backspace && c) return u = 1 == a.anchorNode.nodeType ? null : a.anchorNode.previousElementSibling, setTimeout(e.editTag.bind(e), 0, u), void t1.preventDefault();
                                    if (f() && q(c, Element)) return h = d(c), c.hasAttribute("readonly") || c.remove(), e.DOM.input.focus(), void setTimeout(function() {
                                        T(h), e.DOM.input.click();
                                    });
                                    if ("BR" == a.anchorNode.nodeName) return;
                                    if ((o || c) && 1 == a.anchorNode.nodeType ? g = 0 == a.anchorOffset ? o ? p[0] : null : p[Math.min(p.length, a.anchorOffset) - 1] : o ? g = a.anchorNode.nextElementSibling : q(c, Element) && (g = c), 3 == a.anchorNode.nodeType && !a.anchorNode.nodeValue && a.anchorNode.previousElementSibling && t1.preventDefault(), (c || o) && !i.backspace) return void t1.preventDefault();
                                    if ("Range" != a.type && !a.anchorOffset && a.anchorNode == e.DOM.input && "Delete" != t1.key) return void t1.preventDefault();
                                    if ("Range" != a.type && g && g.hasAttribute("readonly")) return void T(d(g));
                                    "Delete" == t1.key && m && w(a.anchorNode.nextSibling) && e.removeTags(a.anchorNode.nextSibling), clearTimeout(L), L = setTimeout(function() {
                                        var t1 = document.getSelection();
                                        r(e.DOM.input.innerHTML), !o && t1.anchorNode.previousSibling, e.value = [].map.call(p, function(t1, i) {
                                            var n = w(t1);
                                            if (t1.parentNode || n.readonly) return n;
                                            e.trigger("remove", {
                                                tag: t1,
                                                index: i,
                                                data: n
                                            });
                                        }).filter(function(t1) {
                                            return t1;
                                        });
                                    }, 20);
                            }
                            return !0;
                        }
                        var v = "manual" == i.dropdown.position;
                        switch(t1.key){
                            case "Backspace":
                                "select" == i.mode && i.enforceWhitelist && e.value.length ? e.removeTags() : e.state.dropdown.visible && "manual" != i.dropdown.position || "" != t1.target.textContent && 8203 != n.charCodeAt(0) || (!0 === i.backspace ? e.removeTags() : "edit" == i.backspace && setTimeout(e.editTag.bind(e), 0));
                                break;
                            case "Esc":
                            case "Escape":
                                if (e.state.dropdown.visible) return;
                                t1.target.blur();
                                break;
                            case "Down":
                            case "ArrowDown":
                                e.state.dropdown.visible || e.dropdown.show();
                                break;
                            case "ArrowRight":
                                var b = e.state.inputSuggestion || e.state.ddItemData;
                                if (b && i.autoComplete.rightKey) return void e.addTags([
                                    b
                                ], !0);
                                break;
                            case "Tab":
                                var y = "select" == i.mode;
                                if (!n || y) return !0;
                                t1.preventDefault();
                            case "Enter":
                                if (e.state.dropdown.visible && !v) return;
                                t1.preventDefault(), setTimeout(function() {
                                    e.state.dropdown.visible && !v || e.state.actions.selectOption || !i.addTagOn.includes(t1.key.toLowerCase()) || e.addTags(n, !0);
                                });
                        }
                    }).catch(function(t1) {
                        return t1;
                    });
                }
            },
            onInput: function(t1) {
                this.postUpdate();
                var e = this.settings;
                if ("mix" == e.mode) return this.events.callbacks.onMixTagsInput.call(this, t1);
                var i = this.input.normalize.call(this, void 0, {
                    trim: !1
                }), n = i.length >= e.dropdown.enabled, s = {
                    value: i,
                    inputElm: this.DOM.input
                }, a = this.validateTag({
                    value: i
                });
                "select" == e.mode && this.toggleScopeValidation(a), s.isValid = a, this.state.inputText != i && (this.input.set.call(this, i, !1), -1 != i.search(e.delimiters) ? this.addTags(i) && this.input.set.call(this) : e.dropdown.enabled >= 0 && this.dropdown[n ? "show" : "hide"](i), this.trigger("input", s));
            },
            onMixTagsInput: function(t1) {
                var e, i, n, s, a, o, r, l, d = this, c = this.settings, u = this.value.length, h = this.getTagElms(), p = document.createDocumentFragment(), m = window.getSelection().getRangeAt(0), v = [].map.call(h, function(t1) {
                    return w(t1).value;
                });
                if ("deleteContentBackward" == t1.inputType && f() && this.events.callbacks.onKeydown.call(this, {
                    target: t1.target,
                    key: "Backspace"
                }), O(this.getTagElms()), this.value.slice().forEach(function(t1) {
                    t1.readonly && !v.includes(t1.value) && p.appendChild(d.createTagElem(t1));
                }), p.childNodes.length && (m.insertNode(p), this.setRangeAtStartEnd(!1, p.lastChild)), h.length != u) return this.value = [].map.call(this.getTagElms(), function(t1) {
                    return w(t1);
                }), void this.update({
                    withoutChangeEvent: !0
                });
                if (this.hasMaxTags()) return !0;
                if (window.getSelection && (o = window.getSelection()).rangeCount > 0 && 3 == o.anchorNode.nodeType) {
                    if ((m = o.getRangeAt(0).cloneRange()).collapse(!0), m.setStart(o.focusNode, 0), n = (e = m.toString().slice(0, m.endOffset)).split(c.pattern).length - 1, (i = e.match(c.pattern)) && (s = e.slice(e.lastIndexOf(i[i.length - 1]))), s) {
                        if (this.state.actions.ArrowLeft = !1, this.state.tag = {
                            prefix: s.match(c.pattern)[0],
                            value: s.replace(c.pattern, "")
                        }, this.state.tag.baseOffset = o.baseOffset - this.state.tag.value.length, l = this.state.tag.value.match(c.delimiters)) return this.state.tag.value = this.state.tag.value.replace(c.delimiters, ""), this.state.tag.delimiters = l[0], this.addTags(this.state.tag.value, c.dropdown.clearOnSelect), void this.dropdown.hide();
                        a = this.state.tag.value.length >= c.dropdown.enabled;
                        try {
                            r = (r = this.state.flaggedTags[this.state.tag.baseOffset]).prefix == this.state.tag.prefix && r.value[0] == this.state.tag.value[0], this.state.flaggedTags[this.state.tag.baseOffset] && !this.state.tag.value && delete this.state.flaggedTags[this.state.tag.baseOffset];
                        } catch (t1) {}
                        (r || n < this.state.mixMode.matchedPatternCount) && (a = !1);
                    } else this.state.flaggedTags = {};
                    this.state.mixMode.matchedPatternCount = n;
                }
                setTimeout(function() {
                    d.update({
                        withoutChangeEvent: !0
                    }), d.trigger("input", g({}, d.state.tag, {
                        textContent: d.DOM.input.textContent
                    })), d.state.tag && d.dropdown[a ? "show" : "hide"](d.state.tag.value);
                }, 10);
            },
            onInputIE: function(t1) {
                var e = this;
                setTimeout(function() {
                    e.events.callbacks.onInput.call(e, t1);
                });
            },
            observeOriginalInputValue: function() {
                this.DOM.originalInput.parentNode || this.destroy(), this.DOM.originalInput.value != this.DOM.originalInput.tagifyValue && this.loadOriginalValues();
            },
            onClickAnywhere: function(t1) {
                t1.target == this.DOM.scope || this.DOM.scope.contains(t1.target) || (this.toggleFocusClass(!1), this.state.hasFocus = !1, !this.settings.userInput && this.dropdown.hide());
            },
            onClickScope: function(t1) {
                var e = this.settings, i = t1.target.closest("." + e.classNames.tag), n = t1.target === this.DOM.scope, s = +new Date - this.state.hasFocus;
                if (n && "select" != e.mode) this.DOM.input.focus();
                else {
                    if (!t1.target.classList.contains(e.classNames.tagX)) return i && !this.state.editing ? (this.trigger("click", {
                        tag: i,
                        index: this.getNodeIndex(i),
                        data: w(i),
                        event: t1
                    }), void (1 !== e.editTags && 1 !== e.editTags.clicks && "select" != e.mode || this.events.callbacks.onDoubleClickScope.call(this, t1))) : void (t1.target == this.DOM.input && ("mix" == e.mode && this.fixFirefoxLastTagNoCaret(), s > 500 || !e.focusable) ? this.state.dropdown.visible ? this.dropdown.hide() : 0 === e.dropdown.enabled && "mix" != e.mode && this.dropdown.show(this.value.length ? "" : void 0) : "select" != e.mode || 0 !== e.dropdown.enabled || this.state.dropdown.visible || (this.events.callbacks.onDoubleClickScope.call(this, K(function(t1) {
                        for(var e = 1; e < arguments.length; e++){
                            var i = null != arguments[e] ? arguments[e] : {}, n = Object.keys(i);
                            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(i).filter(function(t1) {
                                return Object.getOwnPropertyDescriptor(i, t1).enumerable;
                            }))), n.forEach(function(e) {
                                U(t1, e, i[e]);
                            });
                        }
                        return t1;
                    }({}, t1), {
                        target: this.getTagElms()[0]
                    })), !e.userInput && this.dropdown.show()));
                    this.removeTags(t1.target.parentNode);
                }
            },
            onPaste: function(t1) {
                var e = this;
                t1.preventDefault();
                var i, n, s, a = this.settings;
                if ("select" == a.mode && a.enforceWhitelist || !a.userInput) return !1;
                a.readonly || (n = t1.clipboardData || window.clipboardData, s = n.getData("Text"), a.hooks.beforePaste(t1, {
                    tagify: this,
                    pastedText: s,
                    clipboardData: n
                }).then(function(a) {
                    void 0 === a && (a = s), a && (e.injectAtCaret(a, window.getSelection().getRangeAt(0)), "mix" == e.settings.mode ? e.events.callbacks.onMixTagsInput.call(e, t1) : e.settings.pasteAsTags ? i = e.addTags(e.state.inputText + a, !0) : (e.state.inputText = a, e.dropdown.show(a))), e.trigger("paste", {
                        event: t1,
                        pastedText: s,
                        clipboardData: n,
                        tagsElems: i
                    });
                }).catch(function(t1) {
                    return t1;
                }));
            },
            onDrop: function(t1) {
                t1.preventDefault();
            },
            onEditTagInput: function(t1, e) {
                var i, n = t1.closest("." + this.settings.classNames.tag), s = this.getNodeIndex(n), a = w(n), o = this.input.normalize.call(this, t1), r = (U(i = {}, this.settings.tagTextProp, o), U(i, "__tagId", a.__tagId), i), l = this.validateTag(r);
                this.editTagChangeDetected(g(a, r)) || !0 !== t1.originalIsValid || (l = !0), n.classList.toggle(this.settings.classNames.tagInvalid, !0 !== l), a.__isValid = l, n.title = !0 === l ? a.title || a.value : l, o.length >= this.settings.dropdown.enabled && (this.state.editing && (this.state.editing.value = o), this.dropdown.show(o)), this.trigger("edit:input", {
                    tag: n,
                    index: s,
                    data: g({}, this.value[s], {
                        newValue: o
                    }),
                    event: e
                });
            },
            onEditTagPaste: function(t1, e) {
                var i = (e.clipboardData || window.clipboardData).getData("Text");
                e.preventDefault();
                var n = y(i);
                this.setRangeAtStartEnd(!1, n);
            },
            onEditTagClick: function(t1, e) {
                this.events.callbacks.onClickScope.call(this, e);
            },
            onEditTagFocus: function(t1) {
                this.state.editing = {
                    scope: t1,
                    input: t1.querySelector("[contenteditable]")
                };
            },
            onEditTagBlur: function(t1, e) {
                var i = v.call(this, e.relatedTarget);
                if ("select" == this.settings.mode && i && e.relatedTarget.contains(e.target)) this.dropdown.hide();
                else if (this.state.editing && (this.state.hasFocus || this.toggleFocusClass(), this.DOM.scope.contains(t1))) {
                    var n, s, a, o = this.settings, r = t1.closest("." + o.classNames.tag), l = w(r), d = this.input.normalize.call(this, t1), c = (U(n = {}, o.tagTextProp, d), U(n, "__tagId", l.__tagId), n), u = l.__originalData, h = this.editTagChangeDetected(g(l, c)), p = this.validateTag(c);
                    if (d) {
                        if (h) {
                            var f;
                            if (s = this.hasMaxTags(), a = g({}, u, (U(f = {}, o.tagTextProp, this.trim(d)), U(f, "__isValid", p), f)), o.transformTag.call(this, a, u), !0 !== (p = (!s || !0 === u.__isValid) && this.validateTag(a))) {
                                if (this.trigger("invalid", {
                                    data: a,
                                    tag: r,
                                    message: p
                                }), o.editTags.keepInvalid) return;
                                o.keepInvalidTags ? a.__isValid = p : a = u;
                            } else o.keepInvalidTags && (delete a.title, delete a["aria-invalid"], delete a.class);
                            this.onEditTagDone(r, a);
                        } else this.onEditTagDone(r, u);
                    } else this.onEditTagDone(r);
                }
            },
            onEditTagkeydown: function(t1, e) {
                if (!this.state.composing) switch(this.trigger("edit:keydown", {
                    event: t1
                }), t1.key){
                    case "Esc":
                    case "Escape":
                        this.state.editing = !1, !!e.__tagifyTagData.__originalData.value ? e.parentNode.replaceChild(e.__tagifyTagData.__originalHTML, e) : e.remove();
                        break;
                    case "Enter":
                    case "Tab":
                        t1.preventDefault();
                        setTimeout(function() {
                            return t1.target.blur();
                        }, 0);
                }
            },
            onDoubleClickScope: function(t1) {
                var e, i, n = t1.target.closest("." + this.settings.classNames.tag), s = w(n), a = this.settings;
                n && !1 !== s.editable && (e = n.classList.contains(this.settings.classNames.tagEditing), i = n.hasAttribute("readonly"), a.readonly || e || i || !this.settings.editTags || !a.userInput || this.editTag(n), this.toggleFocusClass(!0), "select" != a.mode && this.trigger("dblclick", {
                    tag: n,
                    index: this.getNodeIndex(n),
                    data: w(n)
                }));
            },
            onInputDOMChange: function(t1) {
                var e = this;
                t1.forEach(function(t1) {
                    t1.addedNodes.forEach(function(t1) {
                        if ("<div><br></div>" == t1.outerHTML) t1.replaceWith(document.createElement("br"));
                        else if (1 == t1.nodeType && t1.querySelector(e.settings.classNames.tagSelector)) {
                            var i, n = document.createTextNode("");
                            3 == t1.childNodes[0].nodeType && "BR" != t1.previousSibling.nodeName && (n = document.createTextNode("\n")), (i = t1).replaceWith.apply(i, z([
                                n
                            ].concat(z(z(t1.childNodes).slice(0, -1))))), T(n);
                        } else if (v.call(e, t1)) {
                            var s;
                            if (3 != (null === (s = t1.previousSibling) || void 0 === s ? void 0 : s.nodeType) || t1.previousSibling.textContent || t1.previousSibling.remove(), t1.previousSibling && "BR" == t1.previousSibling.nodeName) {
                                t1.previousSibling.replaceWith("\n\u200B");
                                for(var a = t1.nextSibling, o = ""; a;)o += a.textContent, a = a.nextSibling;
                                o.trim() && T(t1.previousSibling);
                            } else t1.previousSibling && !w(t1.previousSibling) || t1.before("\u200B");
                        }
                    }), t1.removedNodes.forEach(function(t1) {
                        t1 && "BR" == t1.nodeName && v.call(e, i) && (e.removeTags(i), e.fixFirefoxLastTagNoCaret());
                    });
                });
                var i = this.DOM.input.lastChild;
                i && "" == i.nodeValue && i.remove(), i && "BR" == i.nodeName || this.DOM.input.appendChild(document.createElement("br"));
            }
        }
    };
    function J(t1, e) {
        (null == e || e > t1.length) && (e = t1.length);
        for(var i = 0, n = new Array(e); i < e; i++)n[i] = t1[i];
        return n;
    }
    function G(t1, e, i) {
        return e in t1 ? Object.defineProperty(t1, e, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t1[e] = i, t1;
    }
    function $(t1, e) {
        return null != e && "undefined" != typeof Symbol && e[Symbol.hasInstance] ? !!e[Symbol.hasInstance](t1) : t1 instanceof e;
    }
    function Q(t1) {
        for(var e = 1; e < arguments.length; e++){
            var i = null != arguments[e] ? arguments[e] : {}, n = Object.keys(i);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(i).filter(function(t1) {
                return Object.getOwnPropertyDescriptor(i, t1).enumerable;
            }))), n.forEach(function(e) {
                G(t1, e, i[e]);
            });
        }
        return t1;
    }
    function Y(t1) {
        return function(t1) {
            if (Array.isArray(t1)) return J(t1);
        }(t1) || function(t1) {
            if ("undefined" != typeof Symbol && null != t1[Symbol.iterator] || null != t1["@@iterator"]) return Array.from(t1);
        }(t1) || function(t1, e) {
            if (!t1) return;
            if ("string" == typeof t1) return J(t1, e);
            var i = Object.prototype.toString.call(t1).slice(8, -1);
            "Object" === i && t1.constructor && (i = t1.constructor.name);
            if ("Map" === i || "Set" === i) return Array.from(i);
            if ("Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)) return J(t1, e);
        }(t1) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }();
    }
    function Z(t1, e) {
        if (!t1) {
            n.warn("input element not found", t1);
            var i = new Proxy(this, {
                get: function() {
                    return function() {
                        return i;
                    };
                }
            });
            return i;
        }
        if (t1.__tagify) return n.warn("input element is already Tagified - Same instance is returned.", t1), t1.__tagify;
        var s;
        g(this, function(t1) {
            var e = document.createTextNode(""), i = {};
            function s(t1, i, n) {
                n && i.split(/\s+/g).forEach(function(i) {
                    return e[t1 + "EventListener"].call(e, i, n);
                });
            }
            return {
                removeAllCustomListeners: function() {
                    Object.entries(i).forEach(function(t1) {
                        var e = B(t1, 2), i = e[0];
                        e[1].forEach(function(t1) {
                            return s("remove", i, t1);
                        });
                    }), i = {};
                },
                off: function(t1, e) {
                    return t1 && (e ? s("remove", t1, e) : t1.split(/\s+/g).forEach(function(t1) {
                        var e;
                        null === (e = i[t1]) || void 0 === e || e.forEach(function(e) {
                            return s("remove", t1, e);
                        }), delete i[t1];
                    })), this;
                },
                on: function(t1, e) {
                    return e && "function" == typeof e && (t1.split(/\s+/g).forEach(function(t1) {
                        Array.isArray(i[t1]) ? i[t1].push(e) : i[t1] = [
                            e
                        ];
                    }), s("add", t1, e)), this;
                },
                trigger: function(i, s, a) {
                    var o;
                    if (a = a || {
                        cloneData: !0
                    }, i) {
                        if (t1.settings.isJQueryPlugin) "remove" == i && (i = "removeTag"), jQuery(t1.DOM.originalInput).triggerHandler(i, [
                            s
                        ]);
                        else {
                            try {
                                var r = "object" == typeof s ? s : {
                                    value: s
                                };
                                if ((r = a.cloneData ? g({}, r) : r).tagify = this, s.event && (r.event = this.cloneEvent(s.event)), H(s, Object)) for(var l in s)H(s[l], HTMLElement) && (r[l] = s[l]);
                                o = new CustomEvent(i, {
                                    detail: r
                                });
                            } catch (t1) {
                                n.warn(t1);
                            }
                            e.dispatchEvent(o);
                        }
                    }
                }
            };
        }(this)), this.isFirefox = /firefox|fxios/i.test(navigator.userAgent) && !/seamonkey/i.test(navigator.userAgent), this.isIE = window.document.documentMode, e = e || {}, this.getPersistedData = (s = e.id, function(t1) {
            var e, i = "/" + t1;
            if (1 == localStorage.getItem(j + s + "/v", 1)) try {
                e = JSON.parse(localStorage[j + s + i]);
            } catch (t1) {}
            return e;
        }), this.setPersistedData = function(t1) {
            return t1 ? (localStorage.setItem(j + t1 + "/v", 1), function(e, i) {
                var n = "/" + i, s = JSON.stringify(e);
                e && i && (localStorage.setItem(j + t1 + n, s), dispatchEvent(new Event("storage")));
            }) : function() {};
        }(e.id), this.clearPersistedData = function(t1) {
            return function(e) {
                var i = j + "/" + t1 + "/";
                if (e) localStorage.removeItem(i + e);
                else for(var n in localStorage)n.includes(i) && localStorage.removeItem(n);
            };
        }(e.id), this.applySettings(t1, e), this.state = {
            inputText: "",
            editing: !1,
            composing: !1,
            actions: {},
            mixMode: {},
            dropdown: {},
            flaggedTags: {}
        }, this.value = [], this.listeners = {}, this.DOM = {}, this.build(t1), A.call(this), this.getCSSVars(), this.loadOriginalValues(), this.events.customBinding.call(this), this.events.binding.call(this), t1.autofocus && this.DOM.input.focus(), t1.__tagify = this;
    }
    return Z.prototype = {
        _dropdown: P,
        placeCaretAfterNode: T,
        getSetTagData: w,
        helpers: {
            sameStr: s,
            removeCollectionProp: a,
            omit: o,
            isObject: u,
            parseHTML: l,
            escapeHTML: c,
            extend: g,
            concatWithoutDups: h,
            getUID: m,
            isNodeTag: v
        },
        customEventsList: [
            "change",
            "add",
            "remove",
            "invalid",
            "input",
            "paste",
            "click",
            "keydown",
            "focus",
            "blur",
            "edit:input",
            "edit:beforeUpdate",
            "edit:updated",
            "edit:start",
            "edit:keydown",
            "dropdown:show",
            "dropdown:hide",
            "dropdown:select",
            "dropdown:updated",
            "dropdown:noMatch",
            "dropdown:scroll"
        ],
        dataProps: [
            "__isValid",
            "__removed",
            "__originalData",
            "__originalHTML",
            "__tagId"
        ],
        trim: function(t1) {
            return this.settings.trim && t1 && "string" == typeof t1 ? t1.trim() : t1;
        },
        parseHTML: l,
        templates: R,
        parseTemplate: function(t1, e) {
            return l((t1 = this.settings.templates[t1] || t1).apply(this, e));
        },
        set whitelist (t){
            var e1 = t && Array.isArray(t);
            this.settings.whitelist = e1 ? t : [], this.setPersistedData(e1 ? t : [], "whitelist");
        },
        get whitelist () {
            return this.settings.whitelist;
        },
        set userInput (t){
            this.settings.userInput = !!t, this.setContentEditable(!!t);
        },
        get userInput () {
            return this.settings.userInput;
        },
        generateClassSelectors: function(t1) {
            var e = function(e) {
                var i = e;
                Object.defineProperty(t1, i + "Selector", {
                    get: function() {
                        return "." + this[i].split(" ")[0];
                    }
                });
            };
            for(var i in t1)e(i);
        },
        applySettings: function(t1, e) {
            var i, n;
            x.templates = this.templates;
            var s = g({}, x, "mix" == e.mode ? {
                dropdown: {
                    position: "text"
                }
            } : {}), a = this.settings = g({}, s, e);
            if (a.disabled = t1.hasAttribute("disabled"), a.readonly = a.readonly || t1.hasAttribute("readonly"), a.placeholder = c(t1.getAttribute("placeholder") || a.placeholder || ""), a.required = t1.hasAttribute("required"), this.generateClassSelectors(a.classNames), void 0 === a.dropdown.includeSelectedTags && (a.dropdown.includeSelectedTags = a.duplicates), this.isIE && (a.autoComplete = !1), [
                "whitelist",
                "blacklist"
            ].forEach(function(e) {
                var i = t1.getAttribute("data-" + e);
                i && $(i = i.split(a.delimiters), Array) && (a[e] = i);
            }), "autoComplete" in e && !u(e.autoComplete) && (a.autoComplete = x.autoComplete, a.autoComplete.enabled = e.autoComplete), "mix" == a.mode && (a.pattern = a.pattern || /@/, a.autoComplete.rightKey = !0, a.delimiters = e.delimiters || null, a.tagTextProp && !a.dropdown.searchKeys.includes(a.tagTextProp) && a.dropdown.searchKeys.push(a.tagTextProp)), t1.pattern) try {
                a.pattern = new RegExp(t1.pattern);
            } catch (t1) {}
            if (a.delimiters) {
                a._delimiters = a.delimiters;
                try {
                    a.delimiters = new RegExp(this.settings.delimiters, "g");
                } catch (t1) {}
            }
            a.disabled && (a.userInput = !1), this.TEXTS = Q({}, V, a.texts || {}), ("select" != a.mode || (null === (i = e.dropdown) || void 0 === i ? void 0 : i.enabled)) && a.userInput || (a.dropdown.enabled = 0), a.dropdown.appendTarget = (null === (n = e.dropdown) || void 0 === n ? void 0 : n.appendTarget) || document.body;
            var o = this.getPersistedData("whitelist");
            Array.isArray(o) && (this.whitelist = Array.isArray(a.whitelist) ? h(a.whitelist, o) : o);
        },
        getAttributes: function(t1) {
            var e, i = this.getCustomAttributes(t1), n = "";
            for(e in i)n += " " + e + (void 0 !== t1[e] ? '="'.concat(i[e], '"') : "");
            return n;
        },
        getCustomAttributes: function(t1) {
            if (!u(t1)) return "";
            var e, i = {};
            for(e in t1)"__" != e.slice(0, 2) && "class" != e && t1.hasOwnProperty(e) && void 0 !== t1[e] && (i[e] = c(t1[e]));
            return i;
        },
        setStateSelection: function() {
            var t1 = window.getSelection(), e = {
                anchorOffset: t1.anchorOffset,
                anchorNode: t1.anchorNode,
                range: t1.getRangeAt && t1.rangeCount && t1.getRangeAt(0)
            };
            return this.state.selection = e, e;
        },
        getCSSVars: function() {
            var t1, e, i, n = getComputedStyle(this.DOM.scope, null);
            this.CSSVars = {
                tagHideTransition: (t1 = function(t1) {
                    if (!t1) return {};
                    var e = (t1 = t1.trim().split(" ")[0]).split(/\d+/g).filter(function(t1) {
                        return t1;
                    }).pop().trim();
                    return {
                        value: +t1.split(e).filter(function(t1) {
                            return t1;
                        })[0].trim(),
                        unit: e
                    };
                }((i = "tag-hide-transition", n.getPropertyValue("--" + i))), e = t1.value, "s" == t1.unit ? 1e3 * e : e)
            };
        },
        build: function(t1) {
            var e = this.DOM, i = t1.closest("label");
            this.settings.mixMode.integrated ? (e.originalInput = null, e.scope = t1, e.input = t1) : (e.originalInput = t1, e.originalInput_tabIndex = t1.tabIndex, e.scope = this.parseTemplate("wrapper", [
                t1,
                this.settings
            ]), e.input = e.scope.querySelector(this.settings.classNames.inputSelector), t1.parentNode.insertBefore(e.scope, t1), t1.tabIndex = -1), i && i.setAttribute("for", "");
        },
        destroy: function() {
            this.events.unbindGlobal.call(this), this.DOM.scope.parentNode.removeChild(this.DOM.scope), this.DOM.originalInput.tabIndex = this.DOM.originalInput_tabIndex, delete this.DOM.originalInput.__tagify, this.dropdown.hide(!0), this.removeAllCustomListeners(), clearTimeout(this.dropdownHide__bindEventsTimeout), clearInterval(this.listeners.main.originalInputValueObserverInterval);
        },
        loadOriginalValues: function(t1) {
            var e, i = this.settings;
            if (this.state.blockChangeEvent = !0, void 0 === t1) {
                var n = this.getPersistedData("value");
                t1 = n && !this.DOM.originalInput.value ? n : i.mixMode.integrated ? this.DOM.input.textContent : this.DOM.originalInput.value;
            }
            if (this.removeAllTags(), t1) {
                if ("mix" == i.mode) this.parseMixTags(t1), (e = this.DOM.input.lastChild) && "BR" == e.tagName || this.DOM.input.insertAdjacentHTML("beforeend", "<br>");
                else {
                    try {
                        $(JSON.parse(t1), Array) && (t1 = JSON.parse(t1));
                    } catch (t1) {}
                    this.addTags(t1, !0).forEach(function(t1) {
                        return t1 && t1.classList.add(i.classNames.tagNoAnimation);
                    });
                }
            } else this.postUpdate();
            this.state.lastOriginalValueReported = i.mixMode.integrated ? "" : this.DOM.originalInput.value;
        },
        cloneEvent: function(t1) {
            var e = {};
            for(var i in t1)"path" != i && (e[i] = t1[i]);
            return e;
        },
        loading: function(t1) {
            return this.state.isLoading = t1, this.DOM.scope.classList[t1 ? "add" : "remove"](this.settings.classNames.scopeLoading), this;
        },
        tagLoading: function(t1, e) {
            return t1 && t1.classList[e ? "add" : "remove"](this.settings.classNames.tagLoading), this;
        },
        toggleClass: function(t1, e) {
            "string" == typeof t1 && this.DOM.scope.classList.toggle(t1, e);
        },
        toggleScopeValidation: function(t1) {
            var e = !0 === t1 || void 0 === t1;
            !this.settings.required && t1 && t1 === this.TEXTS.empty && (e = !0), this.toggleClass(this.settings.classNames.tagInvalid, !e), this.DOM.scope.title = e ? "" : t1;
        },
        toggleFocusClass: function(t1) {
            this.toggleClass(this.settings.classNames.focus, !!t1);
        },
        setPlaceholder: function(t1) {
            var e = this;
            [
                "data",
                "aria"
            ].forEach(function(i) {
                return e.DOM.input.setAttribute("".concat(i, "-placeholder"), t1);
            });
        },
        triggerChangeEvent: function() {
            if (!this.settings.mixMode.integrated) {
                var t1 = this.DOM.originalInput, e = this.state.lastOriginalValueReported !== t1.value, i = new CustomEvent("change", {
                    bubbles: !0
                });
                e && (this.state.lastOriginalValueReported = t1.value, i.simulated = !0, t1._valueTracker && t1._valueTracker.setValue(Math.random()), t1.dispatchEvent(i), this.trigger("change", this.state.lastOriginalValueReported), t1.value = this.state.lastOriginalValueReported);
            }
        },
        events: X,
        fixFirefoxLastTagNoCaret: function() {},
        setRangeAtStartEnd: function(t1, e) {
            if (e) {
                t1 = "number" == typeof t1 ? t1 : !!t1, e = e.lastChild || e;
                var i = document.getSelection();
                if ($(i.focusNode, Element) && !this.DOM.input.contains(i.focusNode)) return !0;
                try {
                    i.rangeCount >= 1 && [
                        "Start",
                        "End"
                    ].forEach(function(n) {
                        return i.getRangeAt(0)["set" + n](e, t1 || e.length);
                    });
                } catch (t1) {
                    console.warn(t1);
                }
            }
        },
        insertAfterTag: function(t1, e) {
            if (e = e || this.settings.mixMode.insertAfterTag, t1 && t1.parentNode && e) return e = "string" == typeof e ? document.createTextNode(e) : e, t1.parentNode.insertBefore(e, t1.nextSibling), e;
        },
        editTagChangeDetected: function(t1) {
            var e = t1.__originalData;
            for(var i in e)if (!this.dataProps.includes(i) && t1[i] != e[i]) return !0;
            return !1;
        },
        getTagTextNode: function(t1) {
            return t1.querySelector(this.settings.classNames.tagTextSelector);
        },
        setTagTextNode: function(t1, e) {
            this.getTagTextNode(t1).innerHTML = c(e);
        },
        editTag: function(t1, e) {
            var i = this;
            t1 = t1 || this.getLastTag(), e = e || {};
            var s = this.settings, a = this.getTagTextNode(t1), o = this.getNodeIndex(t1), r = w(t1), l = this.events.callbacks, d = !0;
            if ("select" != s.mode && this.dropdown.hide(), a) {
                if (!$(r, Object) || !("editable" in r) || r.editable) return r = w(t1, {
                    __originalData: g({}, r),
                    __originalHTML: t1.cloneNode(!0)
                }), w(r.__originalHTML, r.__originalData), a.setAttribute("contenteditable", !0), t1.classList.add(s.classNames.tagEditing), a.addEventListener("click", l.onEditTagClick.bind(this, t1)), a.addEventListener("blur", l.onEditTagBlur.bind(this, this.getTagTextNode(t1))), a.addEventListener("input", l.onEditTagInput.bind(this, a)), a.addEventListener("paste", l.onEditTagPaste.bind(this, a)), a.addEventListener("keydown", function(e) {
                    return l.onEditTagkeydown.call(i, e, t1);
                }), a.addEventListener("compositionstart", l.onCompositionStart.bind(this)), a.addEventListener("compositionend", l.onCompositionEnd.bind(this)), e.skipValidation || (d = this.editTagToggleValidity(t1)), a.originalIsValid = d, this.trigger("edit:start", {
                    tag: t1,
                    index: o,
                    data: r,
                    isValid: d
                }), a.focus(), this.setRangeAtStartEnd(!1, a), 0 === s.dropdown.enabled && this.dropdown.show(), this.state.hasFocus = !0, this;
            } else n.warn("Cannot find element in Tag template: .", s.classNames.tagTextSelector);
        },
        editTagToggleValidity: function(t1, e) {
            var i;
            if (e = e || w(t1)) return (i = !("__isValid" in e) || !0 === e.__isValid) || this.removeTagsFromValue(t1), this.update(), t1.classList.toggle(this.settings.classNames.tagNotAllowed, !i), e.__isValid = i, e.__isValid;
            n.warn("tag has no data: ", t1, e);
        },
        onEditTagDone: function(t1, e) {
            t1 = t1 || this.state.editing.scope, e = e || {};
            var i, n, s = {
                tag: t1,
                index: this.getNodeIndex(t1),
                previousData: w(t1),
                data: e
            }, a = this.settings;
            this.trigger("edit:beforeUpdate", s, {
                cloneData: !1
            }), this.state.editing = !1, delete e.__originalData, delete e.__originalHTML, t1 && (void 0 !== (n = e[a.tagTextProp]) ? null === (i = (n += "").trim) || void 0 === i ? void 0 : i.call(n) : a.tagTextProp in e ? void 0 : e.value) ? (t1 = this.replaceTag(t1, e), this.editTagToggleValidity(t1, e), a.a11y.focusableTags ? t1.focus() : T(t1)) : t1 && this.removeTags(t1), this.trigger("edit:updated", s), this.dropdown.hide(), this.settings.keepInvalidTags && this.reCheckInvalidTags();
        },
        replaceTag: function(t1, e) {
            e && "" !== e.value && void 0 !== e.value || (e = t1.__tagifyTagData), e.__isValid && 1 != e.__isValid && g(e, this.getInvalidTagAttrs(e, e.__isValid));
            var i = this.createTagElem(e);
            return t1.parentNode.replaceChild(i, t1), this.updateValueByDOMTags(), i;
        },
        updateValueByDOMTags: function() {
            var t1 = this;
            this.value.length = 0, [].forEach.call(this.getTagElms(), function(e) {
                e.classList.contains(t1.settings.classNames.tagNotAllowed.split(" ")[0]) || t1.value.push(w(e));
            }), this.update();
        },
        injectAtCaret: function(t1, e) {
            var i;
            if (!(e = e || (null === (i = this.state.selection) || void 0 === i ? void 0 : i.range)) && t1) return this.appendMixTags(t1), this;
            var n = y(t1, e);
            return this.setRangeAtStartEnd(!1, n), this.updateValueByDOMTags(), this.update(), this;
        },
        input: {
            set: function() {
                var t1 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], i = this.settings.dropdown.closeOnSelect;
                this.state.inputText = t1, e && (this.DOM.input.innerHTML = c("" + t1)), !t1 && i && this.dropdown.hide.bind(this), this.input.autocomplete.suggest.call(this), this.input.validate.call(this);
            },
            raw: function() {
                return this.DOM.input.textContent;
            },
            validate: function() {
                var t1 = !this.state.inputText || !0 === this.validateTag({
                    value: this.state.inputText
                });
                return this.DOM.input.classList.toggle(this.settings.classNames.inputInvalid, !t1), t1;
            },
            normalize: function(t1, e) {
                var i = t1 || this.DOM.input, n = [];
                i.childNodes.forEach(function(t1) {
                    return 3 == t1.nodeType && n.push(t1.nodeValue);
                }), n = n.join("\n");
                try {
                    n = n.replace(/(?:\r\n|\r|\n)/g, this.settings.delimiters.source.charAt(0));
                } catch (t1) {}
                return n = n.replace(/\s/g, " "), (null == e ? void 0 : e.trim) ? this.trim(n) : n;
            },
            autocomplete: {
                suggest: function(t1) {
                    if (this.settings.autoComplete.enabled) {
                        "object" != typeof (t1 = t1 || {
                            value: ""
                        }) && (t1 = {
                            value: t1
                        });
                        var e = this.dropdown.getMappedValue(t1);
                        if ("number" != typeof e) {
                            var i = this.state.inputText.toLowerCase(), n = e.substr(0, this.state.inputText.length).toLowerCase(), s = e.substring(this.state.inputText.length);
                            e && this.state.inputText && n == i ? (this.DOM.input.setAttribute("data-suggest", s), this.state.inputSuggestion = t1) : (this.DOM.input.removeAttribute("data-suggest"), delete this.state.inputSuggestion);
                        }
                    }
                },
                set: function(t1) {
                    var e = this.DOM.input.getAttribute("data-suggest"), i = t1 || (e ? this.state.inputText + e : null);
                    return !!i && ("mix" == this.settings.mode ? this.replaceTextWithNode(document.createTextNode(this.state.tag.prefix + i)) : (this.input.set.call(this, i), this.setRangeAtStartEnd(!1, this.DOM.input)), this.input.autocomplete.suggest.call(this), this.dropdown.hide(), !0);
                }
            }
        },
        getTagIdx: function(t1) {
            return this.value.findIndex(function(e) {
                return e.__tagId == (t1 || {}).__tagId;
            });
        },
        getNodeIndex: function(t1) {
            var e = 0;
            if (t1) for(; t1 = t1.previousElementSibling;)e++;
            return e;
        },
        getTagElms: function() {
            for(var t1 = arguments.length, e = new Array(t1), i = 0; i < t1; i++)e[i] = arguments[i];
            var n = "." + Y(this.settings.classNames.tag.split(" ")).concat(Y(e)).join(".");
            return [].slice.call(this.DOM.scope.querySelectorAll(n));
        },
        getLastTag: function() {
            var t1 = this.DOM.scope.querySelectorAll("".concat(this.settings.classNames.tagSelector, ":not(.").concat(this.settings.classNames.tagHide, "):not([readonly])"));
            return t1[t1.length - 1];
        },
        isTagDuplicate: function(t1, e, i) {
            var n = 0;
            if ("select" == this.settings.mode) return !1;
            var a = !0, o = !1, r = void 0;
            try {
                for(var l, d = this.value[Symbol.iterator](); !(a = (l = d.next()).done); a = !0){
                    var c = l.value;
                    s(this.trim("" + t1), c.value, e) && i != c.__tagId && n++;
                }
            } catch (t1) {
                o = !0, r = t1;
            } finally{
                try {
                    a || null == d.return || d.return();
                } finally{
                    if (o) throw r;
                }
            }
            return n;
        },
        getTagIndexByValue: function(t1) {
            var e = this, i = [], n = this.settings.dropdown.caseSensitive;
            return this.getTagElms().forEach(function(a, o) {
                a.__tagifyTagData && s(e.trim(a.__tagifyTagData.value), t1, n) && i.push(o);
            }), i;
        },
        getTagElmByValue: function(t1) {
            var e = this.getTagIndexByValue(t1)[0];
            return this.getTagElms()[e];
        },
        flashTag: function(t1) {
            var e = this;
            t1 && (t1.classList.add(this.settings.classNames.tagFlash), setTimeout(function() {
                t1.classList.remove(e.settings.classNames.tagFlash);
            }, 100));
        },
        isTagBlacklisted: function(t1) {
            return t1 = this.trim(t1.toLowerCase()), this.settings.blacklist.filter(function(e) {
                return ("" + e).toLowerCase() == t1;
            }).length;
        },
        isTagWhitelisted: function(t1) {
            return !!this.getWhitelistItem(t1);
        },
        getWhitelistItem: function(t1, e, i) {
            e = e || "value";
            var n, a = this.settings;
            return (i = i || a.whitelist).some(function(i) {
                var o = "string" == typeof i ? i : i[e] || i.value;
                if (s(o, t1, a.dropdown.caseSensitive, a.trim)) return n = "string" == typeof i ? {
                    value: i
                } : i, !0;
            }), n || "value" != e || "value" == a.tagTextProp || (n = this.getWhitelistItem(t1, a.tagTextProp, i)), n;
        },
        validateTag: function(t1) {
            var e = this.settings, i = "value" in t1 ? "value" : e.tagTextProp, n = this.trim(t1[i] + "");
            return (t1[i] + "").trim() ? "mix" != e.mode && e.pattern && $(e.pattern, RegExp) && !e.pattern.test(n) ? this.TEXTS.pattern : !e.duplicates && this.isTagDuplicate(n, e.dropdown.caseSensitive, t1.__tagId) ? this.TEXTS.duplicate : this.isTagBlacklisted(n) || e.enforceWhitelist && !this.isTagWhitelisted(n) ? this.TEXTS.notAllowed : !e.validate || e.validate(t1) : this.TEXTS.empty;
        },
        getInvalidTagAttrs: function(t1, e) {
            return {
                "aria-invalid": !0,
                class: "".concat(t1.class || "", " ").concat(this.settings.classNames.tagNotAllowed).trim(),
                title: e
            };
        },
        hasMaxTags: function() {
            return this.value.length >= this.settings.maxTags && this.TEXTS.exceed;
        },
        setReadonly: function(t1, e) {
            var i = this.settings;
            document.activeElement.blur(), i[e || "readonly"] = t1, this.DOM.scope[(t1 ? "set" : "remove") + "Attribute"](e || "readonly", !0), this.settings.userInput = !0, this.setContentEditable(!t1);
        },
        setContentEditable: function(t1) {
            this.DOM.input.contentEditable = t1, this.DOM.input.tabIndex = t1 ? 0 : -1;
        },
        setDisabled: function(t1) {
            this.setReadonly(t1, "disabled");
        },
        normalizeTags: function(t1) {
            var e = this, i = this.settings, n = i.whitelist, s = i.delimiters, a = i.mode, o = i.tagTextProp, r = [], l = !!n && $(n[0], Object), d = Array.isArray(t1), c = d && t1[0].value, u = function(t1) {
                return (t1 + "").split(s).filter(function(t1) {
                    return t1;
                }).map(function(t1) {
                    var i;
                    return G(i = {}, o, e.trim(t1)), G(i, "value", e.trim(t1)), i;
                });
            };
            if ("number" == typeof t1 && (t1 = t1.toString()), "string" == typeof t1) {
                if (!t1.trim()) return [];
                t1 = u(t1);
            } else if (d) {
                var g;
                t1 = (g = []).concat.apply(g, Y(t1.map(function(t1) {
                    return null != t1.value ? t1 : u(t1);
                })));
            }
            return l && !c && (t1.forEach(function(t1) {
                var i = r.map(function(t1) {
                    return t1.value;
                }), n = e.dropdown.filterListItems.call(e, t1[o], {
                    exact: !0
                });
                e.settings.duplicates || (n = n.filter(function(t1) {
                    return !i.includes(t1.value);
                }));
                var s = n.length > 1 ? e.getWhitelistItem(t1[o], o, n) : n[0];
                s && $(s, Object) ? r.push(s) : "mix" != a && (null == t1.value && (t1.value = t1[o]), r.push(t1));
            }), r.length && (t1 = r)), t1;
        },
        parseMixTags: function(t1) {
            var e = this, i = this.settings, n = i.mixTagsInterpolator, s = i.duplicates, a = i.transformTag, o = i.enforceWhitelist, r = i.maxTags, l = i.tagTextProp, d = [];
            t1 = t1.split(n[0]).map(function(t1, i) {
                var c, u, g, h = t1.split(n[1]), p = h[0], f = d.length == r;
                try {
                    if (p == +p) throw Error;
                    u = JSON.parse(p);
                } catch (t1) {
                    u = e.normalizeTags(p)[0] || {
                        value: p
                    };
                }
                if (a.call(e, u), f || !(h.length > 1) || o && !e.isTagWhitelisted(u.value) || !s && e.isTagDuplicate(u.value)) {
                    if (t1) return i ? n[0] + t1 : t1;
                } else u[c = u[l] ? l : "value"] = e.trim(u[c]), g = e.createTagElem(u), d.push(u), g.classList.add(e.settings.classNames.tagNoAnimation), h[0] = g.outerHTML, e.value.push(u);
                return h.join("");
            }).join(""), this.DOM.input.innerHTML = t1, this.DOM.input.appendChild(document.createTextNode("")), this.DOM.input.normalize();
            var c = this.getTagElms();
            return c.forEach(function(t1, e) {
                return w(t1, d[e]);
            }), this.update({
                withoutChangeEvent: !0
            }), O(c, this.state.hasFocus), t1;
        },
        replaceTextWithNode: function(t1, e) {
            if (this.state.tag || e) {
                e = e || this.state.tag.prefix + this.state.tag.value;
                var i, n, s = this.state.selection || window.getSelection(), a = s.anchorNode, o = this.state.tag.delimiters ? this.state.tag.delimiters.length : 0;
                return a.splitText(s.anchorOffset - o), -1 == (i = a.nodeValue.lastIndexOf(e)) ? !0 : (n = a.splitText(i), t1 && a.parentNode.replaceChild(t1, n), !0);
            }
        },
        prepareNewTagNode: function(t1, e) {
            e = e || {};
            var i = this.settings, n = [], s = {}, a = Object.assign({}, t1, {
                value: t1.value + ""
            });
            if (t1 = Object.assign({}, a), i.transformTag.call(this, t1), t1.__isValid = this.hasMaxTags() || this.validateTag(t1), !0 !== t1.__isValid) {
                if (e.skipInvalid) return;
                if (g(s, this.getInvalidTagAttrs(t1, t1.__isValid), {
                    __preInvalidData: a
                }), t1.__isValid == this.TEXTS.duplicate && this.flashTag(this.getTagElmByValue(t1.value)), !i.createInvalidTags) return void n.push(t1.value);
            }
            return "readonly" in t1 && (t1.readonly ? s["aria-readonly"] = !0 : delete t1.readonly), {
                tagElm: this.createTagElem(t1, s),
                tagData: t1,
                aggregatedInvalidInput: n
            };
        },
        postProcessNewTagNode: function(t1, e) {
            var i = this, n = this.settings, s = e.__isValid;
            s && !0 === s ? (this.value.push(e), this.trigger("add", {
                tag: t1,
                index: this.value.length - 1,
                data: e
            })) : (this.trigger("invalid", {
                data: e,
                index: this.value.length,
                tag: t1,
                message: s
            }), n.keepInvalidTags || setTimeout(function() {
                return i.removeTags(t1, !0);
            }, 1e3)), this.dropdown.position();
        },
        selectTag: function(t1, e) {
            var i = this;
            if (!this.settings.enforceWhitelist || this.isTagWhitelisted(e.value)) {
                this.state.actions.selectOption && setTimeout(function() {
                    return i.setRangeAtStartEnd(!1, i.DOM.input);
                });
                var n = this.getLastTag();
                return n ? this.replaceTag(n, e) : this.appendTag(t1), this.value[0] = e, this.update(), this.trigger("add", {
                    tag: t1,
                    data: e
                }), [
                    t1
                ];
            }
        },
        addEmptyTag: function(t1) {
            var e = g({
                value: ""
            }, t1 || {}), i = this.createTagElem(e);
            w(i, e), this.appendTag(i), this.editTag(i, {
                skipValidation: !0
            }), this.toggleFocusClass(!0);
        },
        addTags: function(t1, e, i) {
            var n = this, s = [], a = this.settings, o = [], r = document.createDocumentFragment();
            if (!t1 || 0 == t1.length) return s;
            switch(t1 = this.normalizeTags(t1), a.mode){
                case "mix":
                    return this.addMixTags(t1);
                case "select":
                    e = !1, this.removeAllTags();
            }
            return this.DOM.input.removeAttribute("style"), t1.forEach(function(t1) {
                var e = n.prepareNewTagNode(t1, {
                    skipInvalid: i || a.skipInvalid
                });
                if (e) {
                    var l = e.tagElm;
                    if (t1 = e.tagData, o = e.aggregatedInvalidInput, s.push(l), "select" == a.mode) return n.selectTag(l, t1);
                    r.appendChild(l), n.postProcessNewTagNode(l, t1);
                }
            }), this.appendTag(r), this.update(), t1.length && e && (this.input.set.call(this, a.createInvalidTags ? "" : o.join(a._delimiters)), this.setRangeAtStartEnd(!1, this.DOM.input)), a.dropdown.enabled && this.dropdown.refilter(), s;
        },
        addMixTags: function(t1) {
            var e = this;
            if ((t1 = this.normalizeTags(t1))[0].prefix || this.state.tag) return this.prefixedTextToTag(t1[0]);
            var i = document.createDocumentFragment();
            return t1.forEach(function(t1) {
                var n = e.prepareNewTagNode(t1);
                i.appendChild(n.tagElm), e.insertAfterTag(n.tagElm), e.postProcessNewTagNode(n.tagElm, n.tagData);
            }), this.appendMixTags(i), i.children;
        },
        appendMixTags: function(t1) {
            var e = !!this.state.selection;
            e ? this.injectAtCaret(t1) : (this.DOM.input.focus(), (e = this.setStateSelection()).range.setStart(this.DOM.input, e.range.endOffset), e.range.setEnd(this.DOM.input, e.range.endOffset), this.DOM.input.appendChild(t1), this.updateValueByDOMTags(), this.update());
        },
        prefixedTextToTag: function(t1) {
            var e, i, n, s = this, a = this.settings, o = null === (e = this.state.tag) || void 0 === e ? void 0 : e.delimiters;
            if (t1.prefix = t1.prefix || this.state.tag ? this.state.tag.prefix : (a.pattern.source || a.pattern)[0], n = this.prepareNewTagNode(t1), i = n.tagElm, this.replaceTextWithNode(i) || this.DOM.input.appendChild(i), setTimeout(function() {
                return i.classList.add(s.settings.classNames.tagNoAnimation);
            }, 300), this.value.push(n.tagData), this.update(), !o) {
                var r = this.insertAfterTag(i) || i;
                setTimeout(T, 0, r);
            }
            return this.state.tag = null, this.postProcessNewTagNode(i, n.tagData), i;
        },
        appendTag: function(t1) {
            var e = this.DOM, i = e.input;
            e.scope.insertBefore(t1, i);
        },
        createTagElem: function(t1, e) {
            t1.__tagId = m();
            var i, n = g({}, t1, Q({
                value: c(t1.value + "")
            }, e));
            return function(t1) {
                for(var e, i = document.createNodeIterator(t1, NodeFilter.SHOW_TEXT, null, !1); e = i.nextNode();)e.textContent.trim() || e.parentNode.removeChild(e);
            }(i = this.parseTemplate("tag", [
                n,
                this
            ])), w(i, t1), i;
        },
        reCheckInvalidTags: function() {
            var t1 = this, e = this.settings;
            this.getTagElms(e.classNames.tagNotAllowed).forEach(function(i, n) {
                var s = w(i), a = t1.hasMaxTags(), o = t1.validateTag(s), r = !0 === o && !a;
                if ("select" == e.mode && t1.toggleScopeValidation(o), r) return s = s.__preInvalidData ? s.__preInvalidData : {
                    value: s.value
                }, t1.replaceTag(i, s);
                i.title = a || o;
            });
        },
        removeTags: function(t1, e, i) {
            var n, s = this, a = this.settings;
            if (t1 = t1 && $(t1, HTMLElement) ? [
                t1
            ] : $(t1, Array) ? t1 : t1 ? [
                t1
            ] : [
                this.getLastTag()
            ], n = t1.reduce(function(t1, e) {
                e && "string" == typeof e && (e = s.getTagElmByValue(e));
                var i = w(e);
                return e && i && !i.readonly && t1.push({
                    node: e,
                    idx: s.getTagIdx(i),
                    data: w(e, {
                        __removed: !0
                    })
                }), t1;
            }, []), i = "number" == typeof i ? i : this.CSSVars.tagHideTransition, "select" == a.mode && (i = 0, this.input.set.call(this)), 1 == n.length && "select" != a.mode && n[0].node.classList.contains(a.classNames.tagNotAllowed) && (e = !0), n.length) return a.hooks.beforeRemoveTag(n, {
                tagify: this
            }).then(function() {
                var t1 = function(t1) {
                    t1.node.parentNode && (t1.node.parentNode.removeChild(t1.node), e ? a.keepInvalidTags && this.trigger("remove", {
                        tag: t1.node,
                        index: t1.idx
                    }) : (this.trigger("remove", {
                        tag: t1.node,
                        index: t1.idx,
                        data: t1.data
                    }), this.dropdown.refilter(), this.dropdown.position(), this.DOM.input.normalize(), a.keepInvalidTags && this.reCheckInvalidTags()));
                };
                i && i > 10 && 1 == n.length ? (function(e) {
                    e.node.style.width = parseFloat(window.getComputedStyle(e.node).width) + "px", document.body.clientTop, e.node.classList.add(a.classNames.tagHide), setTimeout(t1.bind(this), i, e);
                }).call(s, n[0]) : n.forEach(t1.bind(s)), e || (s.removeTagsFromValue(n.map(function(t1) {
                    return t1.node;
                })), s.update(), "select" == a.mode && a.userInput && s.setContentEditable(!0));
            }).catch(function(t1) {});
        },
        removeTagsFromDOM: function() {
            this.getTagElms().forEach(function(t1) {
                return t1.remove();
            });
        },
        removeTagsFromValue: function(t1) {
            var e = this;
            (t1 = Array.isArray(t1) ? t1 : [
                t1
            ]).forEach(function(t1) {
                var i = w(t1), n = e.getTagIdx(i);
                n > -1 && e.value.splice(n, 1);
            });
        },
        removeAllTags: function(t1) {
            var e = this;
            t1 = t1 || {}, this.value = [], "mix" == this.settings.mode ? this.DOM.input.innerHTML = "" : this.removeTagsFromDOM(), this.dropdown.refilter(), this.dropdown.position(), this.state.dropdown.visible && setTimeout(function() {
                e.DOM.input.focus();
            }), "select" == this.settings.mode && (this.input.set.call(this), this.settings.userInput && this.setContentEditable(!0)), this.update(t1);
        },
        postUpdate: function() {
            this.state.blockChangeEvent = !1;
            var t1, e, i = this.settings, n = i.classNames, s = "mix" == i.mode ? i.mixMode.integrated ? this.DOM.input.textContent : this.DOM.originalInput.value.trim() : this.value.length + this.input.raw.call(this).length;
            (this.toggleClass(n.hasMaxTags, this.value.length >= i.maxTags), this.toggleClass(n.hasNoTags, !this.value.length), this.toggleClass(n.empty, !s), "select" == i.mode) && this.toggleScopeValidation(null === (e = this.value) || void 0 === e || null === (t1 = e[0]) || void 0 === t1 ? void 0 : t1.__isValid);
        },
        setOriginalInputValue: function(t1) {
            var e = this.DOM.originalInput;
            this.settings.mixMode.integrated || (e.value = t1, e.tagifyValue = e.value, this.setPersistedData(t1, "value"));
        },
        update: function(t1) {
            clearTimeout(this.debouncedUpdateTimeout), this.debouncedUpdateTimeout = setTimeout((function() {
                var e = this.getInputValue();
                this.setOriginalInputValue(e), this.settings.onChangeAfterBlur && (t1 || {}).withoutChangeEvent || this.state.blockChangeEvent || this.triggerChangeEvent();
                this.postUpdate();
            }).bind(this), 100);
        },
        getInputValue: function() {
            var t1 = this.getCleanValue();
            return "mix" == this.settings.mode ? this.getMixedTagsAsString(t1) : t1.length ? this.settings.originalInputValueFormat ? this.settings.originalInputValueFormat(t1) : JSON.stringify(t1) : "";
        },
        getCleanValue: function(t1) {
            return a(t1 || this.value, this.dataProps);
        },
        getMixedTagsAsString: function() {
            var t1 = "", e = this, i = this.settings, n = i.originalInputValueFormat || JSON.stringify, s = i.mixTagsInterpolator;
            return function i(a) {
                a.childNodes.forEach(function(a) {
                    if (1 == a.nodeType) {
                        var r = w(a);
                        if ("BR" == a.tagName && (t1 += "\r\n"), r && v.call(e, a)) {
                            if (r.__removed) return;
                            t1 += s[0] + n(o(r, e.dataProps)) + s[1];
                        } else a.getAttribute("style") || [
                            "B",
                            "I",
                            "U"
                        ].includes(a.tagName) ? t1 += a.textContent : "DIV" != a.tagName && "P" != a.tagName || (t1 += "\r\n", i(a));
                    } else t1 += a.textContent;
                });
            }(this.DOM.input), t1;
        }
    }, Z.prototype.removeTag = Z.prototype.removeTags, Z;
});



var $9FxNy = parcelRequire("9FxNy");

var $9FxNy = parcelRequire("9FxNy");
// ---------------------------------------------------------------------------------------------------
// https://dmitripavlutin.com/timeout-fetch-request/
async function $12d985f43dc98f9c$var$timeoutFetch(resource, options = {}) {
    let networkTimeout = await (0, $9FxNy.getOption)("input_networkTimeout") * 1000;
    // default networkTimeout to 10 seconds if not set
    if (isNaN(networkTimeout) || networkTimeout === 0) networkTimeout = 10000;
    const { timeout: timeout = networkTimeout } = options;
    const controller = new AbortController();
    const id = setTimeout(()=>controller.abort(), timeout);
    const response = await fetch(resource, {
        ...options,
        signal: controller.signal
    });
    clearTimeout(id);
    return response;
}
async function $12d985f43dc98f9c$export$2e2bcd8739ae039(endpoint, method, data = "") {
    // Determine the server to send the API call to
    let server = "";
    if (typeof data === "object" && "host" in data) server = data.host;
    else server = await (0, $9FxNy.load_data)("credentials", "server");
    // Add trailing slash to the server URL if not provided
    if (server && !server.endsWith("/")) server += "/";
    // Set the headers for the API call
    const headers = {
        "OCS-APIREQUEST": "true",
        "User-Agent": "Bookmarker4Nextcloud"
    };
    // Since v22 you must not send an Authorization header
    if (!data.loginflow) headers["Authorization"] = await $12d985f43dc98f9c$var$authentication();
    // Configure the fetch options
    const fetchInfo = {
        method: method,
        headers: headers,
        credentials: "omit",
        Accept: "application/json"
    };
    // Construct the API call URL
    const url = `${server}${endpoint}?${data}`;
    let result = {};
    try {
        let result = {};
        // Perform the API call and handle the response
        let response = await $12d985f43dc98f9c$var$timeoutFetch(url, fetchInfo);
        if (response.ok) result = await response.json();
        else {
            result = {
                status: response.status,
                statusText: response.statusText
            };
            throw new Error(result.statusText);
        }
        return Promise.resolve(result);
    } catch (error) {
        if (error instanceof TypeError) result = {
            status: -1,
            statusText: error.message
        };
    }
    return Promise.resolve(result);
}
/**
 * Generates an authentication token for the API.
 *
 * @returns {string} The generated authentication token.
 */ async function $12d985f43dc98f9c$var$authentication() {
    // Load the credentials data from the database
    let data = await (0, $9FxNy.load_data)("credentials", "loginname", "appPassword");
    // Generate the authentication token using the loginname and appPassword
    return Promise.resolve("Basic " + btoa(data.loginname + ":" + data.appPassword));
}



var $jzoZb = parcelRequire("jzoZb");



var $9FxNy = parcelRequire("9FxNy");
// -------------------------------------------------------------------------------------------------------
// https://stackoverflow.com/questions/58880234/toggle-chrome-extension-icon-based-on-light-or-dark-mode-browser
async function $f4604fbbedb0b71d$export$2e2bcd8739ae039() {
    const offscreenPath = "../offscreen/offscreen.html";
    // There can ony be one offscreen document
    await chrome.offscreen.createDocument({
        url: chrome.runtime.getURL(offscreenPath),
        reasons: [
            "MATCH_MEDIA"
        ],
        justification: "matchmedia request"
    });
    const isLight = await chrome.runtime.sendMessage({
        target: "offscreen",
        msg: "getBrowserTheme"
    });
    chrome.offscreen.closeDocument();
    return isLight ? "light" : "dark";
}


async function $aa902fff08d7cae0$var$getIconUrl() {
    const browserTheme = await (0, $f4604fbbedb0b71d$export$2e2bcd8739ae039)();
    return chrome.runtime.getURL(`/images/icon-128x128-${browserTheme}.png`);
}
async function $aa902fff08d7cae0$export$cb0ca92a4a718384(response) {
    // load the browser theme to display a visible icon
    const iconUrl = await $aa902fff08d7cae0$var$getIconUrl();
    // user does not want to be notified
    if (!await (0, $9FxNy.getOption)("cbx_successMessage")) return;
    const title = "Bookmarker for Nextcloud";
    // Bookmark was saved successfully
    if (response.status === "success") chrome.notifications.create("", {
        title: title,
        message: `${chrome.i18n.getMessage("BookmarkSuccessfullySaved")}!`,
        iconUrl: iconUrl,
        type: "basic"
    });
    else // There was an error
    chrome.notifications.create("", {
        title: title,
        message: `Error: ${response.statusText}`,
        iconUrl: iconUrl,
        type: "basic"
    });
}
async function $aa902fff08d7cae0$export$47b18c9968a0d81() {
    const iconUrl = await $aa902fff08d7cae0$var$getIconUrl();
    chrome.notifications.create("", {
        title: "Bookmarker for Nextcloud",
        message: "Cache was refreshed",
        iconUrl: iconUrl,
        type: "basic"
    });
}


const $6c64947ffbb5d1e0$var$dbName = "BookmarkerCache";
const $6c64947ffbb5d1e0$var$dbVersion = 2;
async function $6c64947ffbb5d1e0$export$2aca74ef9665e35d(type, forceServer = false) {
    const db = await (0, $jzoZb.openDB)($6c64947ffbb5d1e0$var$dbName, $6c64947ffbb5d1e0$var$dbVersion, {
        upgrade (db) {
            // there's no way to add a store to an existing database
            // without upgrading it, so the creation needs to done
            // with explicit names.
            try {
                db.createObjectStore("keywords", {
                    keyPath: "item"
                });
                db.createObjectStore("folders", {
                    keyPath: "item"
                });
            } catch (e) {
                console.log(e);
            }
        }
    });
    const element = await db.get(type, type);
    const created = await db.get(type, `${type}_created`);
    // data was not found in cache -> load from server
    if (typeof element === "undefined" || Object.keys(element).length === 0 || $6c64947ffbb5d1e0$var$elementExpired(db, type, created, forceServer)) {
        // We call it "keywords" Nextcloud calls it "tags" -> convert
        const datatype = type === "keywords" ? "tag" : "folder";
        let data = await (0, $12d985f43dc98f9c$export$2e2bcd8739ae039)(`index.php/apps/bookmarks/public/rest/v2/${datatype}`, "GET");
        if (type === "folders") data = (0, $d4b346213cb799d9$export$7267d6891ea28004)(data.data);
        $6c64947ffbb5d1e0$export$3a652cb59c327c4(type, data);
        if (forceServer) (0, $aa902fff08d7cae0$export$47b18c9968a0d81)();
        return data;
    } else // data was found in cache -> return cache elements
    return element.value;
}
async function $6c64947ffbb5d1e0$export$3a652cb59c327c4(type, data) {
    const db = await (0, $jzoZb.openDB)($6c64947ffbb5d1e0$var$dbName, $6c64947ffbb5d1e0$var$dbVersion, {
        upgrade (db) {
            db.createObjectStore(type, {
                keyPath: "item"
            });
        }
    });
    db.put(type, {
        item: type,
        value: data
    });
    db.put(type, {
        item: `${type}_created`,
        value: new Date().getTime()
    });
}
async function $6c64947ffbb5d1e0$export$65b4cf737f6efd9a(type, newTags) {
    const db = await (0, $jzoZb.openDB)($6c64947ffbb5d1e0$var$dbName, $6c64947ffbb5d1e0$var$dbVersion, {
        upgrade (db) {
            db.createObjectStore(type, {
                keyPath: "item"
            });
        }
    });
    let cachedTags = await $6c64947ffbb5d1e0$export$2aca74ef9665e35d(type);
    let allTags = cachedTags.concat(newTags);
    db.put(type, {
        item: type,
        value: allTags.sort()
    });
}
// ---------------------------------------------------------------------
function $6c64947ffbb5d1e0$var$elementExpired(db, type, created, forceServer) {
    // if the refresh is forced or no entry has been created, return true
    // fetch can be forced by setting forceServer to true
    if (forceServer || typeof created === "undefined") return true;
    const one_day = 86400000; // one day in milliseconds
    const diff = new Date().getTime() - created.value;
    if (diff > one_day) {
        // remove entry
        db.delete(type, type);
        db.delete(type, `${type}_created`);
        return true;
    }
    return false;
}


function $061509fdd3ce9151$export$2e2bcd8739ae039(DEBUG, ...args) {
    if (DEBUG) console.log(...args);
}


const $d4b346213cb799d9$var$DEBUG = false;
async function $d4b346213cb799d9$export$94ab574f190b122b(force = false) {
    // User does not use folders, so we returns
    if (!await (0, $9FxNy.getOption)("cbx_displayFolders") && !force) return "";
    let folders = await (0, $6c64947ffbb5d1e0$export$2aca74ef9665e35d)("folders");
    if (typeof folders === "undefined" || folders.length === 0) {
        const serverFolders = await (0, $12d985f43dc98f9c$export$2e2bcd8739ae039)("index.php/apps/bookmarks/public/rest/v2/folder", "GET");
        folders = $d4b346213cb799d9$export$7267d6891ea28004(serverFolders.data);
        (0, $6c64947ffbb5d1e0$export$3a652cb59c327c4)("folders", folders);
    }
    (0, $061509fdd3ce9151$export$2e2bcd8739ae039)($d4b346213cb799d9$var$DEBUG, "folders", folders);
    return Promise.resolve(folders);
}
function $d4b346213cb799d9$export$7267d6891ea28004(folders) {
    let userLang = navigator.language || navigator.userLanguage;
    let folderStructure = [
        {
            name: "Root",
            value: "-1"
        }
    ]; // root folder
    // recursively create folder structure
    function json2tree(folders, x = "") {
        folders.sort((a, b)=>a.title.localeCompare(b.title, userLang) > 0);
        for (let f of folders){
            folderStructure.push({
                name: `${x}${f.title}`,
                value: f.id
            });
            if (f.children) json2tree(f.children, `${x}\u2007\u2007`);
        }
    }
    json2tree(folders);
    // convert JSOn to prerendered HTML
    let selectElement = "";
    folderStructure.forEach((folder)=>{
        selectElement += `<option value="${folder.value}">${folder.name}</option>`;
    });
    return selectElement;
}



var $9FxNy = parcelRequire("9FxNy");
async function $7f5490da4e60a762$export$2e2bcd8739ae039(selectbox, folders) {
    if (!folders) return;
    selectbox.innerHTML = folders;
    const folderIDs = await (0, $9FxNy.getOption)("folderIDs");
    if (folderIDs) {
        if (Array.isArray(folderIDs)) Array.from(selectbox.options).forEach((option)=>{
            option.selected = folderIDs.includes(option.value);
        });
        else selectbox.options.selected = folderIDs;
    }
}


const $17e0f98c00a0fc62$var$OPTION_STORE = "options";
document.onreadystatechange = async ()=>{
    if (document.readyState === "complete") {
        document.querySelectorAll("[i18n-data]").forEach((element)=>{
            element.innerText = chrome.i18n.getMessage(element.getAttribute("i18n-data"));
        });
        // set stored tab to active
        let activeTab = document.getElementById("tab_basic");
        const activeTabId = await (0, $9FxNy.load_data)($17e0f98c00a0fc62$var$OPTION_STORE, "activeTab");
        if (activeTabId !== undefined) {
            // deselect basic tab select the stored tab
            activeTab = document.getElementById(activeTabId);
            document.getElementById("tab_basic").classList.remove("tab-active");
            document.getElementById(activeTabId).classList.add("tab-active");
        }
        if (document.readyState === "complete") {
            $17e0f98c00a0fc62$var$setOptions();
            const tabs = document.getElementById("tabs");
            activeTab.classList.add("tab-active");
            const activeContent = document.getElementById(`content_${activeTab.id}`);
            activeContent.classList.remove("hidden");
            tabs.addEventListener("click", (event)=>{
                if (activeTab === event.target) return;
                event.target.classList.add("tab-active");
                activeTab.classList.remove("tab-active");
                $17e0f98c00a0fc62$var$changeContent(activeTab, event.target);
                activeTab = event.target;
                (0, $9FxNy.store_data)($17e0f98c00a0fc62$var$OPTION_STORE, {
                    activeTab: activeTab.id
                });
            });
            // --- zen keywords ----------------------------------------------------------------
            const tagsInput = document.getElementById("input_zenKeywords");
            // TODO: add whitelist
            const tagify = new (0, (/*@__PURE__*/$parcel$interopDefault($cbba9abc09aaccd8$exports)))(tagsInput, {
                backspace: "edit",
                dropdown: {
                    maxItems: 5,
                    highlightFirst: true
                }
            });
            const tags = await (0, $9FxNy.load_data)($17e0f98c00a0fc62$var$OPTION_STORE, "input_zenKeywords");
            tagify.addTags(tags);
            // --- zen folders ---------------------------------------------------------------------
            const folders = await (0, $d4b346213cb799d9$export$94ab574f190b122b)(true);
            const zen_folders = document.getElementById("zen_folders");
            zen_folders.innerHTML = folders;
            const zenFolderOptions = Array.from(zen_folders.options);
            console.log(zenFolderOptions);
            zenFolderOptions.forEach((option)=>{
                console.log(option.selected);
                if (zenFolderOptions.includes(option.value)) console.log("selected");
                option.selected = zenFolderOptions.includes(option.value);
            });
            zen_folders.addEventListener("change", (event)=>{
                const folders = [];
                for (let folder of zen_folders.options)if (folder.selected) folders.push(folder.value);
                (0, $9FxNy.store_data)($17e0f98c00a0fc62$var$OPTION_STORE, {
                    zenFolders: folders
                });
            });
            // --- zen keywords --------------------------------------------------------------------------
            const saveZenTags = ()=>{
                let tags = [];
                tagify.value.forEach((tag)=>{
                    tags.push(tag.value);
                });
                (0, $9FxNy.store_data)($17e0f98c00a0fc62$var$OPTION_STORE, {
                    input_zenKeywords: tags
                });
            };
            // TODO: add whitelist
            tagify.on("add", (e)=>saveZenTags());
            tagify.on("remove", (e)=>saveZenTags());
        }
    }
};
//
// set slider if the user clicks on a heading number
document.getElementById("heading_selectors").addEventListener("click", (event)=>{
    // if target.id is "headings_selector" the user clicked no number
    if (event.target.id === "heading_selectors") return;
    const previousValue = document.getElementById("input_headings_slider").value;
    document.getElementById(`${previousValue}`).classList.remove("selected_heading");
    document.getElementById("input_headings_slider").value = event.target.id;
    document.getElementById(`${event.target.id}`).classList.add("selected_heading");
    (0, $9FxNy.store_data)($17e0f98c00a0fc62$var$OPTION_STORE, {
        input_headings_slider: parseInt($17e0f98c00a0fc62$var$slider.value)
    });
});
// color numbers id sets slider
// save value to database
const $17e0f98c00a0fc62$var$slider = document.getElementById("input_headings_slider");
$17e0f98c00a0fc62$var$slider.addEventListener("input", ()=>{
    const previous_value = $17e0f98c00a0fc62$var$slider.getAttribute("data");
    document.getElementById(`${previous_value}`).classList.remove("selected_heading");
    document.getElementById(`${$17e0f98c00a0fc62$var$slider.value}`).classList.add("selected_heading");
    $17e0f98c00a0fc62$var$slider.setAttribute("data", $17e0f98c00a0fc62$var$slider.value);
    (0, $9FxNy.store_data)($17e0f98c00a0fc62$var$OPTION_STORE, {
        input_headings_slider: parseInt($17e0f98c00a0fc62$var$slider.value)
    });
});
/**
 * Changes the content of the active tab to the target tab.
 *
 * @param {object} activeTab - The active tab object.
 * @param {object} target - The target tab object.
 */ function $17e0f98c00a0fc62$var$changeContent(activeTab, target) {
    const activeContent = document.getElementById(`content_${activeTab.id}`);
    const targetContent = document.getElementById(`content_${target.id}`);
    activeContent.classList.add("hidden");
    targetContent.classList.remove("hidden");
}
/**
 * Sets the options for the user interface.
 *
 * @return {Promise<void>} A Promise that resolves when the options are set.
 */ async function $17e0f98c00a0fc62$var$setOptions() {
    const options = document.getElementById("content");
    const optionsData = await (0, $9FxNy.load_data_all)($17e0f98c00a0fc62$var$OPTION_STORE);
    // set all defaults
    optionsData.forEach((option)=>{
        if (option.item.startsWith("cbx")) {
            let option_element = document.getElementById(option.item);
            if (option_element) option_element.checked = option.value;
        }
        if (option.item.startsWith("input")) {
            let option_element = document.getElementById(option.item);
            if (option_element) option_element.value = option.value;
        }
        // set attribute to slider element, so that we can retrieve the previous
        // value to deselect the selected heading number when the you move the slider
        if (option.item === "input_headings_slider") {
            document.getElementById("input_headings_slider").setAttribute("data", option.value);
            document.getElementById(`${option.value}`).classList.add("selected_heading");
        }
    });
    // --- set event listeners
    // --- set listner for changes on input_networkTimeout
    const input_networkTimeout = document.getElementById("input_networkTimeout");
    input_networkTimeout.addEventListener("input", ()=>{
        (0, $9FxNy.store_data)($17e0f98c00a0fc62$var$OPTION_STORE, {
            input_networkTimeout: parseInt(input_networkTimeout.value)
        });
    });
    options.addEventListener("click", async (event)=>{
        if (event.target.type === "checkbox") {
            const { id: id, checked: checked } = event.target;
            (0, $9FxNy.store_data)($17e0f98c00a0fc62$var$OPTION_STORE, {
                [id]: checked
            });
        }
        if (event.target.type === "submit") {
            console.log("submit", event.target.id);
            switch(event.target.id){
                case "btn_clear_all_data":
                    (0, $9FxNy.clearData)("all");
                    break;
                case "btn_reset_options":
                    (0, $9FxNy.initDefaults)();
                    break;
                case "btn_clear_cache":
                    (0, $9FxNy.clearData)("cache");
                    break;
                case "btn_create_db":
                    $17e0f98c00a0fc62$var$createDB();
            }
        }
        if (event.target.id === "btn_show_options") window.open("displayJson.html?type=options", "Options", "popup");
        if (event.target.id === "btn_show_cache") window.open("displayJson.html?type=cache", "Options", "popup");
    });
}
function $17e0f98c00a0fc62$var$createDB() {
    const dbVersion = document.getElementById("input_dbVersion").value;
    console.log("createDB", dbVersion);
    (0, $9FxNy.createOldDatabase)(dbVersion);
}


//# sourceMappingURL=options.c64989df.js.map
