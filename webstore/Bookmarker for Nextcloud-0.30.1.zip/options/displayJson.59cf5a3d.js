
      var $parcel$global = globalThis;
    
var $parcel$modules = {};
var $parcel$inits = {};

var parcelRequire = $parcel$global["parcelRequire4529"];

if (parcelRequire == null) {
  parcelRequire = function(id) {
    if (id in $parcel$modules) {
      return $parcel$modules[id].exports;
    }
    if (id in $parcel$inits) {
      var init = $parcel$inits[id];
      delete $parcel$inits[id];
      var module = {id: id, exports: {}};
      $parcel$modules[id] = module;
      init.call(module.exports, module, module.exports);
      return module.exports;
    }
    var err = new Error("Cannot find module '" + id + "'");
    err.code = 'MODULE_NOT_FOUND';
    throw err;
  };

  parcelRequire.register = function register(id, init) {
    $parcel$inits[id] = init;
  };

  $parcel$global["parcelRequire4529"] = parcelRequire;
}

var parcelRegister = parcelRequire.register;

var $jzoZb = parcelRequire("jzoZb");

var $9FxNy = parcelRequire("9FxNy");
const $4e9c7eb948312240$var$urlParams = window.location.search || "";
const $4e9c7eb948312240$var$type = $4e9c7eb948312240$var$urlParams.split("=")[1];
let $4e9c7eb948312240$var$data;
if ($4e9c7eb948312240$var$type === "options") $4e9c7eb948312240$var$data = await (0, $9FxNy.load_data_all)("options");
if ($4e9c7eb948312240$var$type === "cache") {
    const db = await (0, $jzoZb.openDB)("BookmarkerCache", 2);
    $4e9c7eb948312240$var$data = await db.get("keywords", "keywords");
}
document.getElementById("jsondata").innerHTML = "<pre>" + JSON.stringify($4e9c7eb948312240$var$data, null, 4) + "</pre>";


//# sourceMappingURL=displayJson.59cf5a3d.js.map
