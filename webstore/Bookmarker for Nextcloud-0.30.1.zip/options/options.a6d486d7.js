
function $parcel$export(e, n, v, s) {
  Object.defineProperty(e, n, {get: v, set: s, enumerable: true, configurable: true});
}

      var $parcel$global = globalThis;
    
var $parcel$modules = {};
var $parcel$inits = {};

var parcelRequire = $parcel$global["parcelRequire4529"];

if (parcelRequire == null) {
  parcelRequire = function(id) {
    if (id in $parcel$modules) {
      return $parcel$modules[id].exports;
    }
    if (id in $parcel$inits) {
      var init = $parcel$inits[id];
      delete $parcel$inits[id];
      var module = {id: id, exports: {}};
      $parcel$modules[id] = module;
      init.call(module.exports, module, module.exports);
      return module.exports;
    }
    var err = new Error("Cannot find module '" + id + "'");
    err.code = 'MODULE_NOT_FOUND';
    throw err;
  };

  parcelRequire.register = function register(id, init) {
    $parcel$inits[id] = init;
  };

  $parcel$global["parcelRequire4529"] = parcelRequire;
}

var parcelRegister = parcelRequire.register;
parcelRegister("9FxNy", function(module, exports) {

$parcel$export(module.exports, "load_data", () => $70a22905a3976f81$export$c0351eb273121c19);
$parcel$export(module.exports, "load_data_all", () => $70a22905a3976f81$export$f6783412e0f475e7);
$parcel$export(module.exports, "store_data", () => $70a22905a3976f81$export$292b19ef67369a8e);
$parcel$export(module.exports, "getOption", () => $70a22905a3976f81$export$6df0712d20d2cc08);
$parcel$export(module.exports, "clearData", () => $70a22905a3976f81$export$ec21c014cef0b1e8);
$parcel$export(module.exports, "initDefaults", () => $70a22905a3976f81$export$56e219def2eb0b12);
$parcel$export(module.exports, "createOldDatabase", () => $70a22905a3976f81$export$e38f80fe8a92025a);

var $jzoZb = parcelRequire("jzoZb");
const $70a22905a3976f81$var$database = "Bookmarker";
const $70a22905a3976f81$var$dbVersion = 2; // since v0.3
async function $70a22905a3976f81$export$c0351eb273121c19(storeName, ...items) {
    console.log("load_data", storeName, items);
    const db1 = await (0, $jzoZb.openDB)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            console.log("upgrade", dbVersion);
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    let result = {};
    for (let item of items){
        const data = await db1.get(storeName, item).catch(()=>{
            return result;
        });
        result[item] = data !== undefined ? data.value : undefined;
    }
    db1.close();
    // if there's only 1 item in the object return the value instead of the object
    if (Object.keys(result).length === 1) return result[Object.keys(result)[0]];
    return Promise.resolve(result);
}
async function $70a22905a3976f81$export$f6783412e0f475e7(storeName) {
    // Open the database connection
    const db1 = await (0, $jzoZb.openDB)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    // Retrieve all data from the specified store
    const result = await db1.getAll(storeName).catch(()=>{
        return result;
    });
    db1.close();
    return Promise.resolve(result);
}
async function $70a22905a3976f81$export$292b19ef67369a8e(storeName, ...items) {
    console.log("store_data", storeName, items);
    const db1 = await (0, $jzoZb.openDB)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    for (let item of items)for(let key in item)db1.put(storeName, {
        item: key,
        value: item[key]
    });
    db1.close();
}
async function $70a22905a3976f81$export$4f99658cecf7d3f3(storeName, ...items) {
    const db1 = await (0, $jzoZb.openDB)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    for (let item of items)db1.delete(storeName, item).catch(()=>{
        return;
    });
    db1.close();
}
async function $70a22905a3976f81$export$487f95a8ccd33481(hash) {
    const db1 = await (0, $jzoZb.openDB)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    db1.put("hashes", {
        item: hash,
        value: new Date().getTime()
    });
    db1.close();
}
async function $70a22905a3976f81$export$6df0712d20d2cc08(optionName) {
    let data = await $70a22905a3976f81$export$c0351eb273121c19("options", optionName);
    if (data === undefined) data = false;
    return data;
}
// ---------------------------------------------------------------------
/**
 * Initialize the necessary object stores in the given database.
 * @param {IDBDatabase} db - The database to initialize the object stores in.
 */ async function $70a22905a3976f81$var$InitializeStores(db1) {
    try {
        db1.createObjectStore("credentials", {
            keyPath: "item"
        });
        db1.createObjectStore("options", {
            keyPath: "item"
        });
        db1.createObjectStore("misc", {
            keyPath: "item"
        });
        db1.createObjectStore("hashes", {
            keyPath: "item"
        });
    } catch (e) {
        console.log(e);
    }
}
async function $70a22905a3976f81$export$ec21c014cef0b1e8(subject) {
    const options_db = await (0, $jzoZb.openDB)("Bookmarker", $70a22905a3976f81$var$dbVersion, {
        upgrade (options_db) {
            $70a22905a3976f81$export$56e219def2eb0b12();
        }
    });
    if (subject === "all") {
        options_db.clear("credentials");
        options_db.clear("options");
        options_db.clear("misc");
        options_db.clear("hashes");
        $70a22905a3976f81$export$56e219def2eb0b12();
    }
    if (subject === "options") {
        options_db.clear("options");
        options_db.createObjectStore("options", {
            keyPath: "item"
        });
    }
    if (subject === "credentials") {
        options_db.clear("credentials");
        db.createObjectStore("credentials", {
            keyPath: "item"
        });
    }
    if (subject === "cache") {
        const cache_db = await (0, $jzoZb.openDB)("BookmarkerCache", $70a22905a3976f81$var$dbVersion, {
            upgrade (cache_db, dbVersion) {
                $70a22905a3976f81$var$InitializeStores(cache_db, dbVersion);
            }
        });
        cache_db.clear("folders");
        cache_db.clear("keywords");
    }
}
async function $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, oldVersion) {
    console.log("oldversion", oldVersion);
    //--- Clean installation
    if (oldVersion === 0) {
        console.log("freshstart");
        await $70a22905a3976f81$var$InitializeStores(db1);
        $70a22905a3976f81$export$56e219def2eb0b12();
    }
    //---  v0.16
    if (oldVersion === 1) {
        // copy data from old version
        const cbx_autoDesc = await $70a22905a3976f81$export$c0351eb273121c19("options", "cbx_autoDesc");
        const cbx_autoTags = await $70a22905a3976f81$export$c0351eb273121c19("options", "cbx_autoTags");
        const cbx_displayFolders = await $70a22905a3976f81$export$c0351eb273121c19("options", "cbx_displayFolders");
        // set default values for new version
        $70a22905a3976f81$export$56e219def2eb0b12();
        // restore data from previous version
        $70a22905a3976f81$export$292b19ef67369a8e("options", {
            cbx_autoTags: cbx_autoTags
        });
        $70a22905a3976f81$export$292b19ef67369a8e("options", {
            cbx_displayFolders: cbx_displayFolders
        });
        $70a22905a3976f81$export$292b19ef67369a8e("options", {
            cbx_autoDescription: cbx_autoDesc
        });
        // delete old data name
        $70a22905a3976f81$export$4f99658cecf7d3f3("options", "cbx_autoDesc");
    }
}
function $70a22905a3976f81$export$56e219def2eb0b12() {
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_showURL: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_showDescription: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_autoDescription: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_showKeywords: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_successMessage: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_alreadyStored: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_autoTags: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        input_headlinesDepth: 3
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        input_networkTimeout: 10
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_reduceKeywords: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        folderIDs: [
            "-1"
        ]
    }); // Default to root folder
}
async function $70a22905a3976f81$export$e38f80fe8a92025a(version) {
    await (0, $jzoZb.deleteDB)("Bookmarker");
    await (0, $jzoZb.deleteDB)("Cache");
    if (version === 1) {
        let db1 = await (0, $jzoZb.openDB)("Bookmarker", 1, {
            upgrade (db1) {
                $70a22905a3976f81$var$InitializeStores(db1);
            }
        });
        db1.put("credentials", {
            item: "appPassword",
            value: "ThisistheApppassword"
        });
        db1.put("credentials", {
            item: "loginname",
            value: "admin"
        });
        db1.put("credentials", {
            item: "server",
            value: "https://pascal:9025"
        });
        db1.put("options", {
            item: "cbx_autoDesc",
            value: true
        });
        db1.put("options", {
            item: "cbx_autoTags",
            value: true
        });
        db1.put("options", {
            item: "cbx_displayFolders",
            value: true
        });
        (0, $jzoZb.openDB)("Cache", $70a22905a3976f81$var$dbVersion, {
            upgrade (db1) {
                db1.createObjectStore("folders", {
                    keyPath: "item"
                });
                db1.createObjectStore("tags", {
                    keyPath: "item"
                });
            }
        });
    }
}

});
parcelRegister("jzoZb", function(module, exports) {

$parcel$export(module.exports, "openDB", () => $e3f4aae069cb52e3$export$ca0ed41b1a2af7e);
$parcel$export(module.exports, "deleteDB", () => $e3f4aae069cb52e3$export$9d6df0ac66a98bb2);
const $e3f4aae069cb52e3$var$instanceOfAny = (object, constructors)=>constructors.some((c)=>object instanceof c);
let $e3f4aae069cb52e3$var$idbProxyableTypes;
let $e3f4aae069cb52e3$var$cursorAdvanceMethods;
// This is a function to prevent it throwing up in node environments.
function $e3f4aae069cb52e3$var$getIdbProxyableTypes() {
    return $e3f4aae069cb52e3$var$idbProxyableTypes || ($e3f4aae069cb52e3$var$idbProxyableTypes = [
        IDBDatabase,
        IDBObjectStore,
        IDBIndex,
        IDBCursor,
        IDBTransaction
    ]);
}
// This is a function to prevent it throwing up in node environments.
function $e3f4aae069cb52e3$var$getCursorAdvanceMethods() {
    return $e3f4aae069cb52e3$var$cursorAdvanceMethods || ($e3f4aae069cb52e3$var$cursorAdvanceMethods = [
        IDBCursor.prototype.advance,
        IDBCursor.prototype.continue,
        IDBCursor.prototype.continuePrimaryKey
    ]);
}
const $e3f4aae069cb52e3$var$transactionDoneMap = new WeakMap();
const $e3f4aae069cb52e3$var$transformCache = new WeakMap();
const $e3f4aae069cb52e3$var$reverseTransformCache = new WeakMap();
function $e3f4aae069cb52e3$var$promisifyRequest(request) {
    const promise = new Promise((resolve, reject)=>{
        const unlisten = ()=>{
            request.removeEventListener("success", success);
            request.removeEventListener("error", error);
        };
        const success = ()=>{
            resolve($e3f4aae069cb52e3$export$4997ffc0176396a6(request.result));
            unlisten();
        };
        const error = ()=>{
            reject(request.error);
            unlisten();
        };
        request.addEventListener("success", success);
        request.addEventListener("error", error);
    });
    // This mapping exists in reverseTransformCache but doesn't doesn't exist in transformCache. This
    // is because we create many promises from a single IDBRequest.
    $e3f4aae069cb52e3$var$reverseTransformCache.set(promise, request);
    return promise;
}
function $e3f4aae069cb52e3$var$cacheDonePromiseForTransaction(tx) {
    // Early bail if we've already created a done promise for this transaction.
    if ($e3f4aae069cb52e3$var$transactionDoneMap.has(tx)) return;
    const done = new Promise((resolve, reject)=>{
        const unlisten = ()=>{
            tx.removeEventListener("complete", complete);
            tx.removeEventListener("error", error);
            tx.removeEventListener("abort", error);
        };
        const complete = ()=>{
            resolve();
            unlisten();
        };
        const error = ()=>{
            reject(tx.error || new DOMException("AbortError", "AbortError"));
            unlisten();
        };
        tx.addEventListener("complete", complete);
        tx.addEventListener("error", error);
        tx.addEventListener("abort", error);
    });
    // Cache it for later retrieval.
    $e3f4aae069cb52e3$var$transactionDoneMap.set(tx, done);
}
let $e3f4aae069cb52e3$var$idbProxyTraps = {
    get (target, prop, receiver) {
        if (target instanceof IDBTransaction) {
            // Special handling for transaction.done.
            if (prop === "done") return $e3f4aae069cb52e3$var$transactionDoneMap.get(target);
            // Make tx.store return the only store in the transaction, or undefined if there are many.
            if (prop === "store") return receiver.objectStoreNames[1] ? undefined : receiver.objectStore(receiver.objectStoreNames[0]);
        }
        // Else transform whatever we get back.
        return $e3f4aae069cb52e3$export$4997ffc0176396a6(target[prop]);
    },
    set (target, prop, value) {
        target[prop] = value;
        return true;
    },
    has (target, prop) {
        if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) return true;
        return prop in target;
    }
};
function $e3f4aae069cb52e3$var$replaceTraps(callback) {
    $e3f4aae069cb52e3$var$idbProxyTraps = callback($e3f4aae069cb52e3$var$idbProxyTraps);
}
function $e3f4aae069cb52e3$var$wrapFunction(func) {
    // Due to expected object equality (which is enforced by the caching in `wrap`), we
    // only create one new func per func.
    // Cursor methods are special, as the behaviour is a little more different to standard IDB. In
    // IDB, you advance the cursor and wait for a new 'success' on the IDBRequest that gave you the
    // cursor. It's kinda like a promise that can resolve with many values. That doesn't make sense
    // with real promises, so each advance methods returns a new promise for the cursor object, or
    // undefined if the end of the cursor has been reached.
    if ($e3f4aae069cb52e3$var$getCursorAdvanceMethods().includes(func)) return function(...args) {
        // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
        // the original object.
        func.apply($e3f4aae069cb52e3$export$debb760848ca95a(this), args);
        return $e3f4aae069cb52e3$export$4997ffc0176396a6(this.request);
    };
    return function(...args) {
        // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
        // the original object.
        return $e3f4aae069cb52e3$export$4997ffc0176396a6(func.apply($e3f4aae069cb52e3$export$debb760848ca95a(this), args));
    };
}
function $e3f4aae069cb52e3$var$transformCachableValue(value) {
    if (typeof value === "function") return $e3f4aae069cb52e3$var$wrapFunction(value);
    // This doesn't return, it just creates a 'done' promise for the transaction,
    // which is later returned for transaction.done (see idbObjectHandler).
    if (value instanceof IDBTransaction) $e3f4aae069cb52e3$var$cacheDonePromiseForTransaction(value);
    if ($e3f4aae069cb52e3$var$instanceOfAny(value, $e3f4aae069cb52e3$var$getIdbProxyableTypes())) return new Proxy(value, $e3f4aae069cb52e3$var$idbProxyTraps);
    // Return the same value back if we're not going to transform it.
    return value;
}
function $e3f4aae069cb52e3$export$4997ffc0176396a6(value) {
    // We sometimes generate multiple promises from a single IDBRequest (eg when cursoring), because
    // IDB is weird and a single IDBRequest can yield many responses, so these can't be cached.
    if (value instanceof IDBRequest) return $e3f4aae069cb52e3$var$promisifyRequest(value);
    // If we've already transformed this value before, reuse the transformed value.
    // This is faster, but it also provides object equality.
    if ($e3f4aae069cb52e3$var$transformCache.has(value)) return $e3f4aae069cb52e3$var$transformCache.get(value);
    const newValue = $e3f4aae069cb52e3$var$transformCachableValue(value);
    // Not all types are transformed.
    // These may be primitive types, so they can't be WeakMap keys.
    if (newValue !== value) {
        $e3f4aae069cb52e3$var$transformCache.set(value, newValue);
        $e3f4aae069cb52e3$var$reverseTransformCache.set(newValue, value);
    }
    return newValue;
}
const $e3f4aae069cb52e3$export$debb760848ca95a = (value)=>$e3f4aae069cb52e3$var$reverseTransformCache.get(value);
/**
 * Open a database.
 *
 * @param name Name of the database.
 * @param version Schema version.
 * @param callbacks Additional callbacks.
 */ function $e3f4aae069cb52e3$export$ca0ed41b1a2af7e(name, version, { blocked: blocked, upgrade: upgrade, blocking: blocking, terminated: terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = $e3f4aae069cb52e3$export$4997ffc0176396a6(request);
    if (upgrade) request.addEventListener("upgradeneeded", (event)=>{
        upgrade($e3f4aae069cb52e3$export$4997ffc0176396a6(request.result), event.oldVersion, event.newVersion, $e3f4aae069cb52e3$export$4997ffc0176396a6(request.transaction), event);
    });
    if (blocked) request.addEventListener("blocked", (event)=>blocked(// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion, event.newVersion, event));
    openPromise.then((db)=>{
        if (terminated) db.addEventListener("close", ()=>terminated());
        if (blocking) db.addEventListener("versionchange", (event)=>blocking(event.oldVersion, event.newVersion, event));
    }).catch(()=>{});
    return openPromise;
}
/**
 * Delete a database.
 *
 * @param name Name of the database.
 */ function $e3f4aae069cb52e3$export$9d6df0ac66a98bb2(name, { blocked: blocked } = {}) {
    const request = indexedDB.deleteDatabase(name);
    if (blocked) request.addEventListener("blocked", (event)=>blocked(// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion, event));
    return $e3f4aae069cb52e3$export$4997ffc0176396a6(request).then(()=>undefined);
}
const $e3f4aae069cb52e3$var$readMethods = [
    "get",
    "getKey",
    "getAll",
    "getAllKeys",
    "count"
];
const $e3f4aae069cb52e3$var$writeMethods = [
    "put",
    "add",
    "delete",
    "clear"
];
const $e3f4aae069cb52e3$var$cachedMethods = new Map();
function $e3f4aae069cb52e3$var$getMethod(target, prop) {
    if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) return;
    if ($e3f4aae069cb52e3$var$cachedMethods.get(prop)) return $e3f4aae069cb52e3$var$cachedMethods.get(prop);
    const targetFuncName = prop.replace(/FromIndex$/, "");
    const useIndex = prop !== targetFuncName;
    const isWrite = $e3f4aae069cb52e3$var$writeMethods.includes(targetFuncName);
    if (// Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || $e3f4aae069cb52e3$var$readMethods.includes(targetFuncName))) return;
    const method = async function(storeName, ...args) {
        // isWrite ? 'readwrite' : undefined gzipps better, but fails in Edge :(
        const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
        let target = tx.store;
        if (useIndex) target = target.index(args.shift());
        // Must reject if op rejects.
        // If it's a write operation, must reject if tx.done rejects.
        // Must reject with op rejection first.
        // Must resolve with op value.
        // Must handle both promises (no unhandled rejections)
        return (await Promise.all([
            target[targetFuncName](...args),
            isWrite && tx.done
        ]))[0];
    };
    $e3f4aae069cb52e3$var$cachedMethods.set(prop, method);
    return method;
}
$e3f4aae069cb52e3$var$replaceTraps((oldTraps)=>({
        ...oldTraps,
        get: (target, prop, receiver)=>$e3f4aae069cb52e3$var$getMethod(target, prop) || oldTraps.get(target, prop, receiver),
        has: (target, prop)=>!!$e3f4aae069cb52e3$var$getMethod(target, prop) || oldTraps.has(target, prop)
    }));
const $e3f4aae069cb52e3$var$advanceMethodProps = [
    "continue",
    "continuePrimaryKey",
    "advance"
];
const $e3f4aae069cb52e3$var$methodMap = {};
const $e3f4aae069cb52e3$var$advanceResults = new WeakMap();
const $e3f4aae069cb52e3$var$ittrProxiedCursorToOriginalProxy = new WeakMap();
const $e3f4aae069cb52e3$var$cursorIteratorTraps = {
    get (target, prop) {
        if (!$e3f4aae069cb52e3$var$advanceMethodProps.includes(prop)) return target[prop];
        let cachedFunc = $e3f4aae069cb52e3$var$methodMap[prop];
        if (!cachedFunc) cachedFunc = $e3f4aae069cb52e3$var$methodMap[prop] = function(...args) {
            $e3f4aae069cb52e3$var$advanceResults.set(this, $e3f4aae069cb52e3$var$ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
        };
        return cachedFunc;
    }
};
async function* $e3f4aae069cb52e3$var$iterate(...args) {
    // tslint:disable-next-line:no-this-assignment
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) cursor = await cursor.openCursor(...args);
    if (!cursor) return;
    cursor;
    const proxiedCursor = new Proxy(cursor, $e3f4aae069cb52e3$var$cursorIteratorTraps);
    $e3f4aae069cb52e3$var$ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    // Map this double-proxy back to the original, so other cursor methods work.
    $e3f4aae069cb52e3$var$reverseTransformCache.set(proxiedCursor, $e3f4aae069cb52e3$export$debb760848ca95a(cursor));
    while(cursor){
        yield proxiedCursor;
        // If one of the advancing methods was not called, call continue().
        cursor = await ($e3f4aae069cb52e3$var$advanceResults.get(proxiedCursor) || cursor.continue());
        $e3f4aae069cb52e3$var$advanceResults.delete(proxiedCursor);
    }
}
function $e3f4aae069cb52e3$var$isIteratorProp(target, prop) {
    return prop === Symbol.asyncIterator && $e3f4aae069cb52e3$var$instanceOfAny(target, [
        IDBIndex,
        IDBObjectStore,
        IDBCursor
    ]) || prop === "iterate" && $e3f4aae069cb52e3$var$instanceOfAny(target, [
        IDBIndex,
        IDBObjectStore
    ]);
}
$e3f4aae069cb52e3$var$replaceTraps((oldTraps)=>({
        ...oldTraps,
        get (target, prop, receiver) {
            if ($e3f4aae069cb52e3$var$isIteratorProp(target, prop)) return $e3f4aae069cb52e3$var$iterate;
            return oldTraps.get(target, prop, receiver);
        },
        has (target, prop) {
            return $e3f4aae069cb52e3$var$isIteratorProp(target, prop) || oldTraps.has(target, prop);
        }
    }));

});



//# sourceMappingURL=options.a6d486d7.js.map
