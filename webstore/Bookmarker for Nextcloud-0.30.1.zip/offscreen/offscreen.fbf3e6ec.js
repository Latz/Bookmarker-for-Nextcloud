chrome.runtime.onMessage.addListener((e,r,s)=>(s(window.matchMedia("(prefers-color-scheme: light)").matches),!0));
//# sourceMappingURL=offscreen.fbf3e6ec.js.map
