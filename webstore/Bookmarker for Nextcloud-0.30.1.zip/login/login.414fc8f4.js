// https://docs.nextcloud.com/server/latest/developer_manual/client_apis/LoginFlow/index.html
const $e3f4aae069cb52e3$var$instanceOfAny = (object, constructors)=>constructors.some((c)=>object instanceof c);
let $e3f4aae069cb52e3$var$idbProxyableTypes;
let $e3f4aae069cb52e3$var$cursorAdvanceMethods;
// This is a function to prevent it throwing up in node environments.
function $e3f4aae069cb52e3$var$getIdbProxyableTypes() {
    return $e3f4aae069cb52e3$var$idbProxyableTypes || ($e3f4aae069cb52e3$var$idbProxyableTypes = [
        IDBDatabase,
        IDBObjectStore,
        IDBIndex,
        IDBCursor,
        IDBTransaction
    ]);
}
// This is a function to prevent it throwing up in node environments.
function $e3f4aae069cb52e3$var$getCursorAdvanceMethods() {
    return $e3f4aae069cb52e3$var$cursorAdvanceMethods || ($e3f4aae069cb52e3$var$cursorAdvanceMethods = [
        IDBCursor.prototype.advance,
        IDBCursor.prototype.continue,
        IDBCursor.prototype.continuePrimaryKey
    ]);
}
const $e3f4aae069cb52e3$var$transactionDoneMap = new WeakMap();
const $e3f4aae069cb52e3$var$transformCache = new WeakMap();
const $e3f4aae069cb52e3$var$reverseTransformCache = new WeakMap();
function $e3f4aae069cb52e3$var$promisifyRequest(request) {
    const promise = new Promise((resolve, reject)=>{
        const unlisten = ()=>{
            request.removeEventListener("success", success);
            request.removeEventListener("error", error);
        };
        const success = ()=>{
            resolve($e3f4aae069cb52e3$export$4997ffc0176396a6(request.result));
            unlisten();
        };
        const error = ()=>{
            reject(request.error);
            unlisten();
        };
        request.addEventListener("success", success);
        request.addEventListener("error", error);
    });
    // This mapping exists in reverseTransformCache but doesn't doesn't exist in transformCache. This
    // is because we create many promises from a single IDBRequest.
    $e3f4aae069cb52e3$var$reverseTransformCache.set(promise, request);
    return promise;
}
function $e3f4aae069cb52e3$var$cacheDonePromiseForTransaction(tx) {
    // Early bail if we've already created a done promise for this transaction.
    if ($e3f4aae069cb52e3$var$transactionDoneMap.has(tx)) return;
    const done = new Promise((resolve, reject)=>{
        const unlisten = ()=>{
            tx.removeEventListener("complete", complete);
            tx.removeEventListener("error", error);
            tx.removeEventListener("abort", error);
        };
        const complete = ()=>{
            resolve();
            unlisten();
        };
        const error = ()=>{
            reject(tx.error || new DOMException("AbortError", "AbortError"));
            unlisten();
        };
        tx.addEventListener("complete", complete);
        tx.addEventListener("error", error);
        tx.addEventListener("abort", error);
    });
    // Cache it for later retrieval.
    $e3f4aae069cb52e3$var$transactionDoneMap.set(tx, done);
}
let $e3f4aae069cb52e3$var$idbProxyTraps = {
    get (target, prop, receiver) {
        if (target instanceof IDBTransaction) {
            // Special handling for transaction.done.
            if (prop === "done") return $e3f4aae069cb52e3$var$transactionDoneMap.get(target);
            // Make tx.store return the only store in the transaction, or undefined if there are many.
            if (prop === "store") return receiver.objectStoreNames[1] ? undefined : receiver.objectStore(receiver.objectStoreNames[0]);
        }
        // Else transform whatever we get back.
        return $e3f4aae069cb52e3$export$4997ffc0176396a6(target[prop]);
    },
    set (target, prop, value) {
        target[prop] = value;
        return true;
    },
    has (target, prop) {
        if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) return true;
        return prop in target;
    }
};
function $e3f4aae069cb52e3$var$replaceTraps(callback) {
    $e3f4aae069cb52e3$var$idbProxyTraps = callback($e3f4aae069cb52e3$var$idbProxyTraps);
}
function $e3f4aae069cb52e3$var$wrapFunction(func) {
    // Due to expected object equality (which is enforced by the caching in `wrap`), we
    // only create one new func per func.
    // Cursor methods are special, as the behaviour is a little more different to standard IDB. In
    // IDB, you advance the cursor and wait for a new 'success' on the IDBRequest that gave you the
    // cursor. It's kinda like a promise that can resolve with many values. That doesn't make sense
    // with real promises, so each advance methods returns a new promise for the cursor object, or
    // undefined if the end of the cursor has been reached.
    if ($e3f4aae069cb52e3$var$getCursorAdvanceMethods().includes(func)) return function(...args) {
        // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
        // the original object.
        func.apply($e3f4aae069cb52e3$export$debb760848ca95a(this), args);
        return $e3f4aae069cb52e3$export$4997ffc0176396a6(this.request);
    };
    return function(...args) {
        // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
        // the original object.
        return $e3f4aae069cb52e3$export$4997ffc0176396a6(func.apply($e3f4aae069cb52e3$export$debb760848ca95a(this), args));
    };
}
function $e3f4aae069cb52e3$var$transformCachableValue(value) {
    if (typeof value === "function") return $e3f4aae069cb52e3$var$wrapFunction(value);
    // This doesn't return, it just creates a 'done' promise for the transaction,
    // which is later returned for transaction.done (see idbObjectHandler).
    if (value instanceof IDBTransaction) $e3f4aae069cb52e3$var$cacheDonePromiseForTransaction(value);
    if ($e3f4aae069cb52e3$var$instanceOfAny(value, $e3f4aae069cb52e3$var$getIdbProxyableTypes())) return new Proxy(value, $e3f4aae069cb52e3$var$idbProxyTraps);
    // Return the same value back if we're not going to transform it.
    return value;
}
function $e3f4aae069cb52e3$export$4997ffc0176396a6(value) {
    // We sometimes generate multiple promises from a single IDBRequest (eg when cursoring), because
    // IDB is weird and a single IDBRequest can yield many responses, so these can't be cached.
    if (value instanceof IDBRequest) return $e3f4aae069cb52e3$var$promisifyRequest(value);
    // If we've already transformed this value before, reuse the transformed value.
    // This is faster, but it also provides object equality.
    if ($e3f4aae069cb52e3$var$transformCache.has(value)) return $e3f4aae069cb52e3$var$transformCache.get(value);
    const newValue = $e3f4aae069cb52e3$var$transformCachableValue(value);
    // Not all types are transformed.
    // These may be primitive types, so they can't be WeakMap keys.
    if (newValue !== value) {
        $e3f4aae069cb52e3$var$transformCache.set(value, newValue);
        $e3f4aae069cb52e3$var$reverseTransformCache.set(newValue, value);
    }
    return newValue;
}
const $e3f4aae069cb52e3$export$debb760848ca95a = (value)=>$e3f4aae069cb52e3$var$reverseTransformCache.get(value);
/**
 * Open a database.
 *
 * @param name Name of the database.
 * @param version Schema version.
 * @param callbacks Additional callbacks.
 */ function $e3f4aae069cb52e3$export$ca0ed41b1a2af7e(name, version, { blocked: blocked, upgrade: upgrade, blocking: blocking, terminated: terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = $e3f4aae069cb52e3$export$4997ffc0176396a6(request);
    if (upgrade) request.addEventListener("upgradeneeded", (event)=>{
        upgrade($e3f4aae069cb52e3$export$4997ffc0176396a6(request.result), event.oldVersion, event.newVersion, $e3f4aae069cb52e3$export$4997ffc0176396a6(request.transaction), event);
    });
    if (blocked) request.addEventListener("blocked", (event)=>blocked(// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion, event.newVersion, event));
    openPromise.then((db)=>{
        if (terminated) db.addEventListener("close", ()=>terminated());
        if (blocking) db.addEventListener("versionchange", (event)=>blocking(event.oldVersion, event.newVersion, event));
    }).catch(()=>{});
    return openPromise;
}
/**
 * Delete a database.
 *
 * @param name Name of the database.
 */ function $e3f4aae069cb52e3$export$9d6df0ac66a98bb2(name, { blocked: blocked } = {}) {
    const request = indexedDB.deleteDatabase(name);
    if (blocked) request.addEventListener("blocked", (event)=>blocked(// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion, event));
    return $e3f4aae069cb52e3$export$4997ffc0176396a6(request).then(()=>undefined);
}
const $e3f4aae069cb52e3$var$readMethods = [
    "get",
    "getKey",
    "getAll",
    "getAllKeys",
    "count"
];
const $e3f4aae069cb52e3$var$writeMethods = [
    "put",
    "add",
    "delete",
    "clear"
];
const $e3f4aae069cb52e3$var$cachedMethods = new Map();
function $e3f4aae069cb52e3$var$getMethod(target, prop) {
    if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) return;
    if ($e3f4aae069cb52e3$var$cachedMethods.get(prop)) return $e3f4aae069cb52e3$var$cachedMethods.get(prop);
    const targetFuncName = prop.replace(/FromIndex$/, "");
    const useIndex = prop !== targetFuncName;
    const isWrite = $e3f4aae069cb52e3$var$writeMethods.includes(targetFuncName);
    if (// Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || $e3f4aae069cb52e3$var$readMethods.includes(targetFuncName))) return;
    const method = async function(storeName, ...args) {
        // isWrite ? 'readwrite' : undefined gzipps better, but fails in Edge :(
        const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
        let target = tx.store;
        if (useIndex) target = target.index(args.shift());
        // Must reject if op rejects.
        // If it's a write operation, must reject if tx.done rejects.
        // Must reject with op rejection first.
        // Must resolve with op value.
        // Must handle both promises (no unhandled rejections)
        return (await Promise.all([
            target[targetFuncName](...args),
            isWrite && tx.done
        ]))[0];
    };
    $e3f4aae069cb52e3$var$cachedMethods.set(prop, method);
    return method;
}
$e3f4aae069cb52e3$var$replaceTraps((oldTraps)=>({
        ...oldTraps,
        get: (target, prop, receiver)=>$e3f4aae069cb52e3$var$getMethod(target, prop) || oldTraps.get(target, prop, receiver),
        has: (target, prop)=>!!$e3f4aae069cb52e3$var$getMethod(target, prop) || oldTraps.has(target, prop)
    }));
const $e3f4aae069cb52e3$var$advanceMethodProps = [
    "continue",
    "continuePrimaryKey",
    "advance"
];
const $e3f4aae069cb52e3$var$methodMap = {};
const $e3f4aae069cb52e3$var$advanceResults = new WeakMap();
const $e3f4aae069cb52e3$var$ittrProxiedCursorToOriginalProxy = new WeakMap();
const $e3f4aae069cb52e3$var$cursorIteratorTraps = {
    get (target, prop) {
        if (!$e3f4aae069cb52e3$var$advanceMethodProps.includes(prop)) return target[prop];
        let cachedFunc = $e3f4aae069cb52e3$var$methodMap[prop];
        if (!cachedFunc) cachedFunc = $e3f4aae069cb52e3$var$methodMap[prop] = function(...args) {
            $e3f4aae069cb52e3$var$advanceResults.set(this, $e3f4aae069cb52e3$var$ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
        };
        return cachedFunc;
    }
};
async function* $e3f4aae069cb52e3$var$iterate(...args) {
    // tslint:disable-next-line:no-this-assignment
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) cursor = await cursor.openCursor(...args);
    if (!cursor) return;
    cursor;
    const proxiedCursor = new Proxy(cursor, $e3f4aae069cb52e3$var$cursorIteratorTraps);
    $e3f4aae069cb52e3$var$ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    // Map this double-proxy back to the original, so other cursor methods work.
    $e3f4aae069cb52e3$var$reverseTransformCache.set(proxiedCursor, $e3f4aae069cb52e3$export$debb760848ca95a(cursor));
    while(cursor){
        yield proxiedCursor;
        // If one of the advancing methods was not called, call continue().
        cursor = await ($e3f4aae069cb52e3$var$advanceResults.get(proxiedCursor) || cursor.continue());
        $e3f4aae069cb52e3$var$advanceResults.delete(proxiedCursor);
    }
}
function $e3f4aae069cb52e3$var$isIteratorProp(target, prop) {
    return prop === Symbol.asyncIterator && $e3f4aae069cb52e3$var$instanceOfAny(target, [
        IDBIndex,
        IDBObjectStore,
        IDBCursor
    ]) || prop === "iterate" && $e3f4aae069cb52e3$var$instanceOfAny(target, [
        IDBIndex,
        IDBObjectStore
    ]);
}
$e3f4aae069cb52e3$var$replaceTraps((oldTraps)=>({
        ...oldTraps,
        get (target, prop, receiver) {
            if ($e3f4aae069cb52e3$var$isIteratorProp(target, prop)) return $e3f4aae069cb52e3$var$iterate;
            return oldTraps.get(target, prop, receiver);
        },
        has (target, prop) {
            return $e3f4aae069cb52e3$var$isIteratorProp(target, prop) || oldTraps.has(target, prop);
        }
    }));


const $70a22905a3976f81$var$database = "Bookmarker";
const $70a22905a3976f81$var$dbVersion = 2; // since v0.3
async function $70a22905a3976f81$export$c0351eb273121c19(storeName, ...items) {
    console.log("load_data", storeName, items);
    const db1 = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            console.log("upgrade", dbVersion);
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    let result = {};
    for (let item of items){
        const data = await db1.get(storeName, item).catch(()=>{
            return result;
        });
        result[item] = data !== undefined ? data.value : undefined;
    }
    db1.close();
    // if there's only 1 item in the object return the value instead of the object
    if (Object.keys(result).length === 1) return result[Object.keys(result)[0]];
    return Promise.resolve(result);
}
async function $70a22905a3976f81$export$f6783412e0f475e7(storeName) {
    // Open the database connection
    const db1 = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    // Retrieve all data from the specified store
    const result = await db1.getAll(storeName).catch(()=>{
        return result;
    });
    db1.close();
    return Promise.resolve(result);
}
async function $70a22905a3976f81$export$292b19ef67369a8e(storeName, ...items) {
    console.log("store_data", storeName, items);
    const db1 = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    for (let item of items)for(let key in item)db1.put(storeName, {
        item: key,
        value: item[key]
    });
    db1.close();
}
async function $70a22905a3976f81$export$4f99658cecf7d3f3(storeName, ...items) {
    const db1 = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    for (let item of items)db1.delete(storeName, item).catch(()=>{
        return;
    });
    db1.close();
}
async function $70a22905a3976f81$export$487f95a8ccd33481(hash) {
    const db1 = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)($70a22905a3976f81$var$database, $70a22905a3976f81$var$dbVersion, {
        upgrade (db1, dbVersion) {
            $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, dbVersion);
        }
    });
    db1.put("hashes", {
        item: hash,
        value: new Date().getTime()
    });
    db1.close();
}
async function $70a22905a3976f81$export$6df0712d20d2cc08(optionName) {
    let data = await $70a22905a3976f81$export$c0351eb273121c19("options", optionName);
    if (data === undefined) data = false;
    return data;
}
// ---------------------------------------------------------------------
/**
 * Initialize the necessary object stores in the given database.
 * @param {IDBDatabase} db - The database to initialize the object stores in.
 */ async function $70a22905a3976f81$var$InitializeStores(db1) {
    try {
        db1.createObjectStore("credentials", {
            keyPath: "item"
        });
        db1.createObjectStore("options", {
            keyPath: "item"
        });
        db1.createObjectStore("misc", {
            keyPath: "item"
        });
        db1.createObjectStore("hashes", {
            keyPath: "item"
        });
    } catch (e) {
        console.log(e);
    }
}
async function $70a22905a3976f81$export$ec21c014cef0b1e8(subject) {
    const options_db = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)("Bookmarker", $70a22905a3976f81$var$dbVersion, {
        upgrade (options_db) {
            $70a22905a3976f81$export$56e219def2eb0b12();
        }
    });
    if (subject === "all") {
        options_db.clear("credentials");
        options_db.clear("options");
        options_db.clear("misc");
        options_db.clear("hashes");
        $70a22905a3976f81$export$56e219def2eb0b12();
    }
    if (subject === "options") {
        options_db.clear("options");
        options_db.createObjectStore("options", {
            keyPath: "item"
        });
    }
    if (subject === "credentials") {
        options_db.clear("credentials");
        db.createObjectStore("credentials", {
            keyPath: "item"
        });
    }
    if (subject === "cache") {
        const cache_db = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)("BookmarkerCache", $70a22905a3976f81$var$dbVersion, {
            upgrade (cache_db, dbVersion) {
                $70a22905a3976f81$var$InitializeStores(cache_db, dbVersion);
            }
        });
        cache_db.clear("folders");
        cache_db.clear("keywords");
    }
}
async function $70a22905a3976f81$export$1eff49f4dcec6ffc(db1, oldVersion) {
    console.log("oldversion", oldVersion);
    //--- Clean installation
    if (oldVersion === 0) {
        console.log("freshstart");
        await $70a22905a3976f81$var$InitializeStores(db1);
        $70a22905a3976f81$export$56e219def2eb0b12();
    }
    //---  v0.16
    if (oldVersion === 1) {
        // copy data from old version
        const cbx_autoDesc = await $70a22905a3976f81$export$c0351eb273121c19("options", "cbx_autoDesc");
        const cbx_autoTags = await $70a22905a3976f81$export$c0351eb273121c19("options", "cbx_autoTags");
        const cbx_displayFolders = await $70a22905a3976f81$export$c0351eb273121c19("options", "cbx_displayFolders");
        // set default values for new version
        $70a22905a3976f81$export$56e219def2eb0b12();
        // restore data from previous version
        $70a22905a3976f81$export$292b19ef67369a8e("options", {
            cbx_autoTags: cbx_autoTags
        });
        $70a22905a3976f81$export$292b19ef67369a8e("options", {
            cbx_displayFolders: cbx_displayFolders
        });
        $70a22905a3976f81$export$292b19ef67369a8e("options", {
            cbx_autoDescription: cbx_autoDesc
        });
        // delete old data name
        $70a22905a3976f81$export$4f99658cecf7d3f3("options", "cbx_autoDesc");
    }
}
function $70a22905a3976f81$export$56e219def2eb0b12() {
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_showURL: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_showDescription: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_autoDescription: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_showKeywords: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_successMessage: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_alreadyStored: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_autoTags: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        input_headlinesDepth: 3
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        input_networkTimeout: 10
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        cbx_reduceKeywords: true
    });
    $70a22905a3976f81$export$292b19ef67369a8e("options", {
        folderIDs: [
            "-1"
        ]
    }); // Default to root folder
}
async function $70a22905a3976f81$export$e38f80fe8a92025a(version) {
    await (0, $e3f4aae069cb52e3$export$9d6df0ac66a98bb2)("Bookmarker");
    await (0, $e3f4aae069cb52e3$export$9d6df0ac66a98bb2)("Cache");
    if (version === 1) {
        let db1 = await (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)("Bookmarker", 1, {
            upgrade (db1) {
                $70a22905a3976f81$var$InitializeStores(db1);
            }
        });
        db1.put("credentials", {
            item: "appPassword",
            value: "ThisistheApppassword"
        });
        db1.put("credentials", {
            item: "loginname",
            value: "admin"
        });
        db1.put("credentials", {
            item: "server",
            value: "https://pascal:9025"
        });
        db1.put("options", {
            item: "cbx_autoDesc",
            value: true
        });
        db1.put("options", {
            item: "cbx_autoTags",
            value: true
        });
        db1.put("options", {
            item: "cbx_displayFolders",
            value: true
        });
        (0, $e3f4aae069cb52e3$export$ca0ed41b1a2af7e)("Cache", $70a22905a3976f81$var$dbVersion, {
            upgrade (db1) {
                db1.createObjectStore("folders", {
                    keyPath: "item"
                });
                db1.createObjectStore("tags", {
                    keyPath: "item"
                });
            }
        });
    }
}


// ---------------------------------------------------------------------------------------------------
// https://dmitripavlutin.com/timeout-fetch-request/
async function $12d985f43dc98f9c$var$timeoutFetch(resource, options = {}) {
    let networkTimeout = await (0, $70a22905a3976f81$export$6df0712d20d2cc08)("input_networkTimeout") * 1000;
    // default networkTimeout to 10 seconds if not set
    if (isNaN(networkTimeout) || networkTimeout === 0) networkTimeout = 10000;
    const { timeout: timeout = networkTimeout } = options;
    const controller = new AbortController();
    const id = setTimeout(()=>controller.abort(), timeout);
    const response = await fetch(resource, {
        ...options,
        signal: controller.signal
    });
    clearTimeout(id);
    return response;
}
async function $12d985f43dc98f9c$export$2e2bcd8739ae039(endpoint, method, data = "") {
    // Determine the server to send the API call to
    let server = "";
    if (typeof data === "object" && "host" in data) server = data.host;
    else server = await (0, $70a22905a3976f81$export$c0351eb273121c19)("credentials", "server");
    // Add trailing slash to the server URL if not provided
    if (server && !server.endsWith("/")) server += "/";
    // Set the headers for the API call
    const headers = {
        "OCS-APIREQUEST": "true",
        "User-Agent": "Bookmarker4Nextcloud"
    };
    // Since v22 you must not send an Authorization header
    if (!data.loginflow) headers["Authorization"] = await $12d985f43dc98f9c$var$authentication();
    // Configure the fetch options
    const fetchInfo = {
        method: method,
        headers: headers,
        credentials: "omit",
        Accept: "application/json"
    };
    // Construct the API call URL
    const url = `${server}${endpoint}?${data}`;
    let result = {};
    try {
        let result = {};
        // Perform the API call and handle the response
        let response = await $12d985f43dc98f9c$var$timeoutFetch(url, fetchInfo);
        if (response.ok) result = await response.json();
        else {
            result = {
                status: response.status,
                statusText: response.statusText
            };
            throw new Error(result.statusText);
        }
        return Promise.resolve(result);
    } catch (error) {
        if (error instanceof TypeError) result = {
            status: -1,
            statusText: error.message
        };
    }
    return Promise.resolve(result);
}
/**
 * Generates an authentication token for the API.
 *
 * @returns {string} The generated authentication token.
 */ async function $12d985f43dc98f9c$var$authentication() {
    // Load the credentials data from the database
    let data = await (0, $70a22905a3976f81$export$c0351eb273121c19)("credentials", "loginname", "appPassword");
    // Generate the authentication token using the loginname and appPassword
    return Promise.resolve("Basic " + btoa(data.loginname + ":" + data.appPassword));
}



// Generated file. Do not edit
var $fb48d464d3ef175d$export$d5b01f7a8fa2906a = {
    "202": "Accepted",
    "502": "Bad Gateway",
    "400": "Bad Request",
    "409": "Conflict",
    "100": "Continue",
    "201": "Created",
    "417": "Expectation Failed",
    "424": "Failed Dependency",
    "403": "Forbidden",
    "504": "Gateway Timeout",
    "410": "Gone",
    "505": "HTTP Version Not Supported",
    "418": "I'm a teapot",
    "419": "Insufficient Space on Resource",
    "507": "Insufficient Storage",
    "500": "Internal Server Error",
    "411": "Length Required",
    "423": "Locked",
    "420": "Method Failure",
    "405": "Method Not Allowed",
    "301": "Moved Permanently",
    "302": "Moved Temporarily",
    "207": "Multi-Status",
    "300": "Multiple Choices",
    "511": "Network Authentication Required",
    "204": "No Content",
    "203": "Non Authoritative Information",
    "406": "Not Acceptable",
    "404": "Not Found",
    "501": "Not Implemented",
    "304": "Not Modified",
    "200": "OK",
    "206": "Partial Content",
    "402": "Payment Required",
    "308": "Permanent Redirect",
    "412": "Precondition Failed",
    "428": "Precondition Required",
    "102": "Processing",
    "103": "Early Hints",
    "426": "Upgrade Required",
    "407": "Proxy Authentication Required",
    "431": "Request Header Fields Too Large",
    "408": "Request Timeout",
    "413": "Request Entity Too Large",
    "414": "Request-URI Too Long",
    "416": "Requested Range Not Satisfiable",
    "205": "Reset Content",
    "303": "See Other",
    "503": "Service Unavailable",
    "101": "Switching Protocols",
    "307": "Temporary Redirect",
    "429": "Too Many Requests",
    "401": "Unauthorized",
    "451": "Unavailable For Legal Reasons",
    "422": "Unprocessable Entity",
    "415": "Unsupported Media Type",
    "305": "Use Proxy",
    "421": "Misdirected Request"
};
var $fb48d464d3ef175d$export$188f590e8751a1b9 = {
    "Accepted": 202,
    "Bad Gateway": 502,
    "Bad Request": 400,
    "Conflict": 409,
    "Continue": 100,
    "Created": 201,
    "Expectation Failed": 417,
    "Failed Dependency": 424,
    "Forbidden": 403,
    "Gateway Timeout": 504,
    "Gone": 410,
    "HTTP Version Not Supported": 505,
    "I'm a teapot": 418,
    "Insufficient Space on Resource": 419,
    "Insufficient Storage": 507,
    "Internal Server Error": 500,
    "Length Required": 411,
    "Locked": 423,
    "Method Failure": 420,
    "Method Not Allowed": 405,
    "Moved Permanently": 301,
    "Moved Temporarily": 302,
    "Multi-Status": 207,
    "Multiple Choices": 300,
    "Network Authentication Required": 511,
    "No Content": 204,
    "Non Authoritative Information": 203,
    "Not Acceptable": 406,
    "Not Found": 404,
    "Not Implemented": 501,
    "Not Modified": 304,
    "OK": 200,
    "Partial Content": 206,
    "Payment Required": 402,
    "Permanent Redirect": 308,
    "Precondition Failed": 412,
    "Precondition Required": 428,
    "Processing": 102,
    "Early Hints": 103,
    "Upgrade Required": 426,
    "Proxy Authentication Required": 407,
    "Request Header Fields Too Large": 431,
    "Request Timeout": 408,
    "Request Entity Too Large": 413,
    "Request-URI Too Long": 414,
    "Requested Range Not Satisfiable": 416,
    "Reset Content": 205,
    "See Other": 303,
    "Service Unavailable": 503,
    "Switching Protocols": 101,
    "Temporary Redirect": 307,
    "Too Many Requests": 429,
    "Unauthorized": 401,
    "Unavailable For Legal Reasons": 451,
    "Unprocessable Entity": 422,
    "Unsupported Media Type": 415,
    "Use Proxy": 305,
    "Misdirected Request": 421
};


function $1d6373435ab4aa88$export$91293bff868a9015(statusCode) {
    var result = (0, $fb48d464d3ef175d$export$d5b01f7a8fa2906a)[statusCode.toString()];
    if (!result) throw new Error("Status code does not exist: " + statusCode);
    return result;
}
function $1d6373435ab4aa88$export$68868794c9b58e55(reasonPhrase) {
    var result = (0, $fb48d464d3ef175d$export$188f590e8751a1b9)[reasonPhrase];
    if (!result) throw new Error("Reason phrase does not exist: " + reasonPhrase);
    return result;
}
var $1d6373435ab4aa88$export$32e796a9286f339b = $1d6373435ab4aa88$export$91293bff868a9015;


document.onreadystatechange = async ()=>{
    if (document.readyState === "complete") {
        document.getElementById("msg").innerText = "";
        document.getElementById("testServer").innerHTML = chrome.i18n.getMessage("OpenLoginPage");
        document.getElementById("testServer").addEventListener("click", ()=>{
            $d8440fbebea4513c$var$openServerPage();
        });
        document.getElementById("serverName").addEventListener("keydown", (event)=>{
            if (event.key === "Enter") {
                event.preventDefault();
                $d8440fbebea4513c$var$openServerPage();
            }
        });
    }
};
async function $d8440fbebea4513c$var$openServerPage() {
    // clear possible error message
    document.getElementById("error").innerHTML = "";
    document.getElementById("msg").innerHTML = "";
    const testServer = document.getElementById("testServer");
    testServer.innerHTML = `${chrome.i18n.getMessage("Loading")}...`;
    const host = document.getElementById("serverName").value;
    const endpoint = "index.php/login/v2";
    const method = "POST";
    try {
        const response = await (0, $12d985f43dc98f9c$export$2e2bcd8739ae039)(endpoint, method, {
            host: host,
            loginflow: true
        });
        response.login ? $d8440fbebea4513c$var$loginPoll(response) : $d8440fbebea4513c$var$serverError(response);
    } catch (e) {
        console.log("!", e);
    }
}
async function $d8440fbebea4513c$var$loginPoll(request) {
    let authorized = false;
    let authCheck;
    // add maximum number of attempts to avoid infinite loop if the user leaves the tab
    // without logging in
    const maxAttempts = 300;
    let attempts = 0;
    // remember login page id so that we can close it If there was an time.
    const loginPage = await chrome.tabs.create({
        url: request.login
    });
    console.log("\uD83D\uDE80 ~ loginPoll ~ loginPage:", loginPage);
    while(!authorized && attempts < maxAttempts){
        try {
            authCheck = await fetch(request.poll.endpoint, {
                credentials: "omit",
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    Origin: request.poll.value
                },
                body: `token=${request.poll.token}`
            });
            authorized = authCheck.ok;
        } catch (e) {
            console.log("!!!", e);
        }
        // put a little pause between requests
        await new Promise((resolve)=>{
            setTimeout(()=>resolve(), 1000);
        });
        attempts++;
    }
    // User did not interact after maxAttempts iterations
    if (maxAttempts === attempts) {
        chrome.runtime.sendMessage({
            msg: "maxAttempts",
            loginPage: loginPage
        });
        document.getElementById("testServer").innerHTML = chrome.i18n.getMessage("OpenLoginPage");
        document.getElementById("serverName").focus();
    } else {
        // Otherwise, save login credentials.
        let response = await authCheck.json();
        (0, $70a22905a3976f81$export$292b19ef67369a8e)("credentials", {
            appPassword: response.appPassword,
            loginname: response.loginName,
            server: response.server
        });
    }
}
function $d8440fbebea4513c$var$serverError(response) {
    // display error message
    const msg = document.getElementById("msg");
    const errorDiv = document.getElementById("error");
    const testServer = document.getElementById("testServer");
    errorDiv.innerText = `${chrome.i18n.getMessage("LoginServerError")}!`;
    if (response.status > 0) msg.innerText = `${response.status}  - ${(0, $1d6373435ab4aa88$export$91293bff868a9015)(response.status)}`;
    else if (response.statusText) msg.innerText = ` ${response.statusText}`;
    testServer.innerHTML = chrome.i18n.getMessage("OpenLoginPage");
    document.getElementById("serverName").focus();
}


//# sourceMappingURL=login.414fc8f4.js.map
